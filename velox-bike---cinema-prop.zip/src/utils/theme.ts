import { MaterialColorPalette } from '../types';

// Helper to convert hex to RGB
export function hexToRgb(hex: string): { r: number; g: number; b: number } {
  let cleanHex = hex.replace('#', '');
  if (cleanHex.length === 3) {
    cleanHex = cleanHex.split('').map(c => c + c).join('');
  }
  const num = parseInt(cleanHex, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

// Helper to convert RGB to HSL
export function rgbToHsl(r: number, g: number, b: number): { h: number; s: number; l: number } {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }
  return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
}

// Helper to convert HSL to Hex
export function hslToHex(h: number, s: number, l: number): string {
  l /= 100;
  const a = (s * Math.min(l, 1 - l)) / 100;
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color)
      .toString(16)
      .padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

// Generate Material You 3 Tonal Palette from Seed Color
export function generateMaterialPalette(seedHex: string, id: string, name: string): MaterialColorPalette {
  const { r, g, b } = hexToRgb(seedHex);
  const { h, s } = rgbToHsl(r, g, b);

  // Material You Tones (Light and Dark)
  const pLight = hslToHex(h, Math.min(s, 75), 38);
  const onPLight = '#FFFFFF';
  const pContLight = hslToHex(h, Math.min(s, 60), 90);
  const onPContLight = hslToHex(h, Math.min(s, 90), 15);

  const secLight = hslToHex((h + 20) % 360, Math.min(s * 0.5, 40), 45);
  const onSecLight = '#FFFFFF';
  const secContLight = hslToHex((h + 20) % 360, Math.min(s * 0.4, 45), 92);

  const surfLight = hslToHex(h, Math.min(s * 0.15, 12), 98);
  const surfVarLight = hslToHex(h, Math.min(s * 0.25, 20), 91);
  const onSurfLight = hslToHex(h, Math.min(s * 0.2, 15), 12);
  const onSurfVarLight = hslToHex(h, Math.min(s * 0.2, 20), 30);
  const bgLight = hslToHex(h, Math.min(s * 0.12, 10), 99);
  const onBgLight = onSurfLight;
  const outlineLight = hslToHex(h, Math.min(s * 0.25, 20), 65);

  // Dark tones
  const pDark = hslToHex(h, Math.min(s, 80), 75);
  const onPDark = hslToHex(h, Math.min(s, 90), 12);
  const pContDark = hslToHex(h, Math.min(s, 60), 28);
  const onPContDark = hslToHex(h, Math.min(s, 80), 92);

  const secDark = hslToHex((h + 20) % 360, Math.min(s * 0.5, 45), 72);
  const onSecDark = hslToHex((h + 20) % 360, Math.min(s * 0.6, 50), 14);
  const secContDark = hslToHex((h + 20) % 360, Math.min(s * 0.4, 40), 25);

  const surfDark = hslToHex(h, Math.min(s * 0.2, 14), 10);
  const surfVarDark = hslToHex(h, Math.min(s * 0.25, 20), 18);
  const onSurfDark = hslToHex(h, Math.min(s * 0.15, 10), 92);
  const onSurfVarDark = hslToHex(h, Math.min(s * 0.2, 15), 76);
  const bgDark = hslToHex(h, Math.min(s * 0.2, 12), 7);
  const onBgDark = onSurfDark;
  const outlineDark = hslToHex(h, Math.min(s * 0.2, 18), 40);

  return {
    id,
    name,
    seedHex,
    light: {
      primary: pLight,
      onPrimary: onPLight,
      primaryContainer: pContLight,
      onPrimaryContainer: onPContLight,
      secondary: secLight,
      onSecondary: onSecLight,
      secondaryContainer: secContLight,
      surface: surfLight,
      surfaceVariant: surfVarLight,
      onSurface: onSurfLight,
      onSurfaceVariant: onSurfVarLight,
      background: bgLight,
      onBackground: onBgLight,
      outline: outlineLight,
      error: '#BA1A1A',
    },
    dark: {
      primary: pDark,
      onPrimary: onPDark,
      primaryContainer: pContDark,
      onPrimaryContainer: onPContDark,
      secondary: secDark,
      onSecondary: onSecDark,
      secondaryContainer: secContDark,
      surface: surfDark,
      surfaceVariant: surfVarDark,
      onSurface: onSurfDark,
      onSurfaceVariant: onSurfVarDark,
      background: bgDark,
      onBackground: onBgDark,
      outline: outlineDark,
      error: '#FFB4AB',
    },
  };
}

// Built-in Material You Preset Palettes
export const MATERIAL_YOU_PRESETS: MaterialColorPalette[] = [
  generateMaterialPalette('#1A73E8', 'monet-google-blue', 'Android Pixel Blue'),
  generateMaterialPalette('#2E7D32', 'monet-forest-green', 'Sage & Forest Green'),
  generateMaterialPalette('#E65100', 'monet-sunset-amber', 'Amber & Terra Cotta'),
  generateMaterialPalette('#7B1FA2', 'monet-lavender-purple', 'Lavender & Violet'),
  generateMaterialPalette('#00838F', 'monet-cyan-teal', 'Ocean Teal'),
  generateMaterialPalette('#C2185B', 'monet-berry-crimson', 'Berry & Rose'),
  generateMaterialPalette('#455A64', 'monet-slate-neutral', 'Nordic Slate'),
];

// Extract dominant color from image file for dynamic wallpaper theming
export async function extractSeedFromImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve('#1A73E8');
          return;
        }
        // Small canvas for performance
        canvas.width = 64;
        canvas.height = 64;
        ctx.drawImage(img, 0, 0, 64, 64);
        const data = ctx.getImageData(0, 0, 64, 64).data;

        let bestScore = -1;
        let bestRgb = { r: 26, g: 115, b: 232 };

        // Sample pixels to find vibrant dominant color
        for (let i = 0; i < data.length; i += 16) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          const a = data[i + 3];
          if (a < 128) continue;

          const { s, l } = rgbToHsl(r, g, b);
          // Prefer saturated colors that aren't too dark or too washed out
          if (l > 15 && l < 85 && s > 20) {
            const score = s * (1 - Math.abs(l - 50) / 50);
            if (score > bestScore) {
              bestScore = score;
              bestRgb = { r, g, b };
            }
          }
        }

        const hex = `#${bestRgb.r.toString(16).padStart(2, '0')}${bestRgb.g.toString(16).padStart(2, '0')}${bestRgb.b.toString(16).padStart(2, '0')}`;
        resolve(hex);
      };
      img.onerror = () => resolve('#1A73E8');
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read image'));
    reader.readAsDataURL(file);
  });
}

// Apply CSS variables to document
export function applyMaterialYouTheme(palette: MaterialColorPalette, isDark: boolean) {
  const root = document.documentElement;
  const theme = isDark ? palette.dark : palette.light;

  if (isDark) {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }

  root.style.setProperty('--md-sys-color-primary', theme.primary);
  root.style.setProperty('--md-sys-color-on-primary', theme.onPrimary);
  root.style.setProperty('--md-sys-color-primary-container', theme.primaryContainer);
  root.style.setProperty('--md-sys-color-on-primary-container', theme.onPrimaryContainer);
  root.style.setProperty('--md-sys-color-secondary', theme.secondary);
  root.style.setProperty('--md-sys-color-on-secondary', theme.onSecondary);
  root.style.setProperty('--md-sys-color-secondary-container', theme.secondaryContainer);
  root.style.setProperty('--md-sys-color-surface', theme.surface);
  root.style.setProperty('--md-sys-color-surface-variant', theme.surfaceVariant);
  root.style.setProperty('--md-sys-color-on-surface', theme.onSurface);
  root.style.setProperty('--md-sys-color-on-surface-variant', theme.onSurfaceVariant);
  root.style.setProperty('--md-sys-color-background', theme.background);
  root.style.setProperty('--md-sys-color-on-background', theme.onBackground);
  root.style.setProperty('--md-sys-color-outline', theme.outline);
  root.style.setProperty('--md-sys-color-error', theme.error);
}
