import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  QrCode,
  Bike,
  Battery,
  MapPin,
  Sparkles,
  Zap,
  Flame,
  Turtle,
  Shield,
  CreditCard,
  ChevronRight,
  Sliders,
  Play,
  RotateCcw,
  Navigation,
} from 'lucide-react';
import {
  BikeInfo,
  MaterialColorPalette,
  PaymentCard,
  RideReceipt,
  RideState,
  TariffOption,
  ThemeMode,
} from './types';
import { DEFAULT_TARIFFS, SAMPLE_BIKES } from './data/mockBikes';
import {
  MATERIAL_YOU_PRESETS,
  applyMaterialYouTheme,
} from './utils/theme';
import { Header } from './components/Header';
import { ScannerModal } from './components/ScannerModal';
import { TariffSelector } from './components/TariffSelector';
import { PaymentModal } from './components/PaymentModal';
import { ActiveRideView } from './components/ActiveRideView';
import { ReceiptModal } from './components/ReceiptModal';
import { SettingsModal } from './components/SettingsModal';
import { CinemaHelpModal } from './components/CinemaHelpModal';
import { ComposeCodeModal } from './components/ComposeCodeModal';
import { MapBackground } from './components/MapBackground';

export default function App() {
  // Theme & Material You state
  const [themeMode, setThemeMode] = useState<ThemeMode>('dark');
  const [palette, setPalette] = useState<MaterialColorPalette>(MATERIAL_YOU_PRESETS[0]);
  const isDark = themeMode === 'dark';

  // App Flow Steps: 'home' | 'tariff' | 'riding'
  const [appStep, setAppStep] = useState<'home' | 'tariff' | 'riding'>('home');

  // Active selections
  const [activeBike, setActiveBike] = useState<BikeInfo | null>(null);
  const [selectedTariff, setSelectedTariff] = useState<TariffOption>(DEFAULT_TARIFFS[1]);
  const [paymentCard, setPaymentCard] = useState<PaymentCard>({
    cardNumber: '2200 4819 0293 8812',
    expiry: '12/28',
    cvv: '777',
    cardholder: 'MOVIE ACTOR',
    cardBrand: 'mir',
  });

  // Modals state
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isCinemaHelpOpen, setIsCinemaHelpOpen] = useState(false);
  const [isComposeCodeOpen, setIsComposeCodeOpen] = useState(false);
  const [currentReceipt, setCurrentReceipt] = useState<RideReceipt | null>(null);

  // Apply Material You CSS variables on theme/palette change
  useEffect(() => {
    applyMaterialYouTheme(palette, isDark);
  }, [palette, isDark]);

  // Handle Bike Scanned / Selected
  const handleBikeScanned = (bike: BikeInfo) => {
    setActiveBike(bike);
    setIsScannerOpen(false);
    setAppStep('tariff');
  };

  // Proceed to Fake Payment
  const handleProceedToRent = () => {
    setIsPaymentOpen(true);
  };

  // Payment Approved -> Start Active Ride
  const handlePaymentSuccess = (card: PaymentCard) => {
    setPaymentCard(card);
    setIsPaymentOpen(false);
    setAppStep('riding');
  };

  // Finish Ride -> Open Fiscal Receipt
  const handleFinishRide = (finalStats: {
    durationSeconds: number;
    distanceMeters: number;
    totalCost: number;
    averageSpeedKmH: number;
  }) => {
    if (!activeBike) return;

    const receipt: RideReceipt = {
      receiptId: `VLX-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: Date.now(),
      bike: activeBike,
      tariff: selectedTariff,
      paymentCard,
      startTime: Date.now() - finalStats.durationSeconds * 1000,
      endTime: Date.now(),
      durationSeconds: finalStats.durationSeconds,
      distanceMeters: finalStats.distanceMeters,
      averageSpeedKmH: finalStats.averageSpeedKmH,
      unlockFee: selectedTariff.unlockFee,
      distanceFee: +((finalStats.distanceMeters / 100) * selectedTariff.pricePer100m).toFixed(1),
      timeFee: +((finalStats.durationSeconds / 60) * 2).toFixed(1),
      totalPaid: finalStats.totalCost,
      transactionRef: `AUTH_OK_${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
    };

    setCurrentReceipt(receipt);
    setAppStep('home');
  };

  // Reset for new take
  const handleNewRideTake = () => {
    setCurrentReceipt(null);
    setActiveBike(null);
    setAppStep('home');
  };

  return (
    <div
      className="min-h-screen w-full flex flex-col items-center justify-between relative overflow-x-hidden font-sans transition-colors duration-300"
      style={{
        backgroundColor: 'var(--md-sys-color-background)',
        color: 'var(--md-sys-color-on-background)',
      }}
    >
      {/* Background Street Map Graphic */}
      <MapBackground
        isRiding={appStep === 'riding'}
        activeBikeCode={activeBike?.id}
      />

      {/* Top Header & Android 12+ Status Bar */}
      <Header
        themeMode={themeMode}
        isDark={isDark}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenCinemaHelp={() => setIsCinemaHelpOpen(true)}
        onOpenComposeCode={() => setIsComposeCodeOpen(true)}
        activeBike={activeBike}
        isRiding={appStep === 'riding'}
      />

      {/* Main Dynamic View Area */}
      <main className="w-full flex-1 flex flex-col items-center justify-start z-10 px-2 sm:px-4 py-2">
        <AnimatePresence mode="wait">
          {/* 1. HOME SCREEN: Find Bike & Scan QR */}
          {appStep === 'home' && (
            <motion.div
              key="home-screen"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="w-full max-w-lg space-y-4 my-auto py-2"
            >
              {/* Hero Action Card: Scan QR Code */}
              <div
                className="p-6 rounded-3xl border shadow-xl relative overflow-hidden transition-all"
                style={{
                  backgroundColor: 'var(--md-sys-color-surface)',
                  borderColor: 'var(--md-sys-color-outline)',
                }}
              >
                <div className="relative z-10 space-y-4">
                  <div className="flex items-center justify-between">
                    <span
                      className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full"
                      style={{
                        backgroundColor: 'var(--md-sys-color-primary-container)',
                        color: 'var(--md-sys-color-on-primary-container)',
                      }}
                    >
                      ⚡ Кино-шеринг
                    </span>
                    <span className="text-xs opacity-70 font-medium">Реквизит для съёмок</span>
                  </div>

                  <div>
                    <h2 className="text-2xl sm:text-3xl font-black tracking-tight leading-tight">
                      Арендуйте велосипед за 1 клик
                    </h2>
                    <p className="text-xs sm:text-sm opacity-80 mt-1">
                      Отсканируйте QR-код на руле или раме для выбора передачи и начала поездки
                    </p>
                  </div>

                  {/* Big Scan QR Button */}
                  <button
                    id="btn-main-scan-qr"
                    onClick={() => setIsScannerOpen(true)}
                    className="w-full py-4 px-6 rounded-3xl font-extrabold text-base flex items-center justify-center gap-3 shadow-lg transition-all active:scale-[0.98] hover:brightness-105 cursor-pointer"
                    style={{
                      backgroundColor: 'var(--md-sys-color-primary)',
                      color: 'var(--md-sys-color-on-primary)',
                    }}
                  >
                    <QrCode className="w-6 h-6 stroke-[2.5]" />
                    <span>Отсканировать QR-код</span>
                  </button>
                </div>
              </div>

              {/* 3 Speed Gears Preview Summary */}
              <div
                className="p-4 rounded-3xl border"
                style={{
                  backgroundColor: 'var(--md-sys-color-surface-variant)',
                  color: 'var(--md-sys-color-on-surface-variant)',
                  borderColor: 'transparent',
                }}
              >
                <div className="flex items-center justify-between mb-2.5 px-1">
                  <span className="text-xs font-bold uppercase tracking-wider">
                    Доступные передачи скорости
                  </span>
                  <span className="text-[11px] opacity-70">3 режима</span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2.5 rounded-2xl bg-black/5 dark:bg-white/5 space-y-1">
                    <div className="w-7 h-7 rounded-xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
                      <Turtle className="w-4 h-4" />
                    </div>
                    <span className="font-bold block text-[11px]">1. Медленно</span>
                    <span className="text-[10px] opacity-70 block">до 15 км/ч</span>
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400 block text-[11px]">5 ₽ / 100м</span>
                  </div>

                  <div className="p-2.5 rounded-2xl bg-black/5 dark:bg-white/5 space-y-1">
                    <div className="w-7 h-7 rounded-xl bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto">
                      <Zap className="w-4 h-4" />
                    </div>
                    <span className="font-bold block text-[11px]">2. Средняя</span>
                    <span className="text-[10px] opacity-70 block">до 25 км/ч</span>
                    <span className="font-semibold text-blue-600 dark:text-blue-400 block text-[11px]">8 ₽ / 100м</span>
                  </div>

                  <div className="p-2.5 rounded-2xl bg-black/5 dark:bg-white/5 space-y-1">
                    <div className="w-7 h-7 rounded-xl bg-rose-500/20 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
                      <Flame className="w-4 h-4" />
                    </div>
                    <span className="font-bold block text-[11px]">3. Экспресс</span>
                    <span className="text-[10px] opacity-70 block">до 45 км/ч</span>
                    <span className="font-semibold text-rose-600 dark:text-rose-400 block text-[11px]">14 ₽ / 100м</span>
                  </div>
                </div>
              </div>

              {/* Nearby Props for 1-Tap Quick Filming */}
              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <h3 className="text-xs font-bold uppercase tracking-wider opacity-75">
                    Реквизит поблизости (готово к дублю)
                  </h3>
                  <span className="text-[11px] opacity-60">GPS активен</span>
                </div>

                <div className="space-y-2">
                  {SAMPLE_BIKES.map((bike) => (
                    <div
                      key={bike.id}
                      onClick={() => handleBikeScanned(bike)}
                      id={`sample-bike-row-${bike.id}`}
                      className="p-3.5 rounded-2xl border flex items-center justify-between transition-all hover:scale-[1.01] active:scale-[0.99] cursor-pointer shadow-sm"
                      style={{
                        backgroundColor: 'var(--md-sys-color-surface)',
                        borderColor: 'var(--md-sys-color-outline)',
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center"
                          style={{
                            backgroundColor: 'var(--md-sys-color-secondary-container)',
                            color: 'var(--md-sys-color-on-secondary-container)',
                          }}
                        >
                          <Bike className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-sm">{bike.codeName}</h4>
                          <div className="flex items-center gap-2 text-xs opacity-70">
                            <span className="flex items-center gap-0.5">
                              <Battery className="w-3 h-3 text-emerald-500" /> {bike.batteryLevel}%
                            </span>
                            <span>•</span>
                            <span className="truncate max-w-[140px]">{bike.locationName}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 text-xs font-bold" style={{ color: 'var(--md-sys-color-primary)' }}>
                        <span>Выбрать</span>
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* 2. TARIFF & SPEED LIMIT SELECTION */}
          {appStep === 'tariff' && activeBike && (
            <TariffSelector
              key="tariff-screen"
              bike={activeBike}
              selectedTariff={selectedTariff}
              onSelectTariff={(t) => setSelectedTariff(t)}
              onProceedToRent={handleProceedToRent}
              onRescan={() => setIsScannerOpen(true)}
            />
          )}

          {/* 3. ACTIVE RIDE SCREEN: Speedometer, Distance, Dynamic Total Cost */}
          {appStep === 'riding' && activeBike && (
            <ActiveRideView
              key="ride-screen"
              bike={activeBike}
              tariff={selectedTariff}
              paymentCard={paymentCard}
              onFinishRide={handleFinishRide}
            />
          )}
        </AnimatePresence>
      </main>

      {/* MODALS */}
      {/* 1. Scanner Modal */}
      <ScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onBikeScanned={handleBikeScanned}
      />

      {/* 2. Fake Payment Modal */}
      {activeBike && (
        <PaymentModal
          isOpen={isPaymentOpen}
          onClose={() => setIsPaymentOpen(false)}
          bike={activeBike}
          tariff={selectedTariff}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* 3. Fiscal Receipt Modal */}
      <ReceiptModal
        receipt={currentReceipt}
        onClose={() => setCurrentReceipt(null)}
        onNewRide={handleNewRideTake}
      />

      {/* 4. Settings & Material You Palette Extractor */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        themeMode={themeMode}
        onThemeModeChange={setThemeMode}
        currentPalette={palette}
        onPaletteChange={setPalette}
      />

      {/* 5. Cinema Shoot Instructions Modal */}
      <CinemaHelpModal
        isOpen={isCinemaHelpOpen}
        onClose={() => setIsCinemaHelpOpen(false)}
        onQuickStart={() => {
          handleBikeScanned(SAMPLE_BIKES[0]);
        }}
      />

      {/* 6. Jetpack Compose M3 Code & Architecture Inspector */}
      <ComposeCodeModal
        isOpen={isComposeCodeOpen}
        onClose={() => setIsComposeCodeOpen(false)}
      />
    </div>
  );
}
