import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CreditCard,
  Lock,
  X,
  CheckCircle2,
  Sparkles,
  Shield,
  Smartphone,
  ChevronRight,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { BikeInfo, PaymentCard, TariffOption } from '../types';
import { playPaymentApprovedSound, playBikeUnlockSound } from '../utils/audio';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  bike: BikeInfo;
  tariff: TariffOption;
  onPaymentSuccess: (card: PaymentCard) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  bike,
  tariff,
  onPaymentSuccess,
}) => {
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [cardholder, setCardholder] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  // Detect card brand from number
  const detectBrand = (num: string): PaymentCard['cardBrand'] => {
    const clean = num.replace(/\s+/g, '');
    if (clean.startsWith('2200') || clean.startsWith('2204') || clean.startsWith('2')) return 'mir';
    if (clean.startsWith('4')) return 'visa';
    if (clean.startsWith('51') || clean.startsWith('55')) return 'mastercard';
    if (clean.toLowerCase().includes('tink') || clean.startsWith('5213')) return 'tinkoff';
    if (clean.toLowerCase().includes('sber') || clean.startsWith('4276')) return 'sber';
    return 'generic';
  };

  // Format card number as 4-digit groups
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    // Format lightly but accept any characters
    const parts = val.replace(/\s+/g, '').match(/.{1,4}/g);
    setCardNumber(parts ? parts.join(' ') : val);
  };

  // 1-Tap Quick presets for rapid movie filming
  const fillPresetCard = (type: 'tinkoff' | 'sber' | 'mir') => {
    if (type === 'tinkoff') {
      setCardNumber('5213 2400 9812 4419');
      setExpiry('11/29');
      setCvv('777');
      setCardholder('ALEX VOLKOV');
    } else if (type === 'sber') {
      setCardNumber('4276 3800 1928 3381');
      setExpiry('08/28');
      setCvv('382');
      setCardholder('DMITRIY SMIRNOV');
    } else {
      setCardNumber('2200 7001 8492 5501');
      setExpiry('12/30');
      setCvv('910');
      setCardholder('MOVIE HERO');
    }
  };

  const handlePay = () => {
    setIsProcessing(true);

    // Accept literally any input (provide defaults if blank for smooth movie shoot)
    const finalCard: PaymentCard = {
      cardNumber: cardNumber || '2200 4819 0293 8812',
      expiry: expiry || '12/28',
      cvv: cvv || '999',
      cardholder: cardholder || 'CINEMA ACTOR',
      cardBrand: detectBrand(cardNumber || '2200'),
    };

    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      playPaymentApprovedSound();
      playBikeUnlockSound();

      // Confetti burst
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.7 },
        });
      } catch {
        // ignore
      }

      setTimeout(() => {
        onPaymentSuccess(finalCard);
      }, 1200);
    }, 1000);
  };

  const brand = detectBrand(cardNumber);

  return (
    <AnimatePresence>
      <div
        id="payment-modal"
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-md rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[95vh]"
          style={{
            backgroundColor: 'var(--md-sys-color-surface)',
            color: 'var(--md-sys-color-on-surface)',
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-black/5 dark:border-white/10">
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5" style={{ color: 'var(--md-sys-color-primary)' }} />
              <h2 className="font-bold text-lg">Оплата аренды</h2>
            </div>
            {!isProcessing && !isSuccess && (
              <button
                id="btn-close-payment"
                onClick={onClose}
                className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Success Overlay */}
          {isSuccess ? (
            <div className="p-8 flex flex-col items-center justify-center text-center space-y-4 my-auto">
              <motion.div
                initial={{ scale: 0.5, rotate: -20 }}
                animate={{ scale: 1, rotate: 0 }}
                className="w-20 h-20 rounded-full flex items-center justify-center shadow-lg"
                style={{
                  backgroundColor: 'var(--md-sys-color-primary-container)',
                  color: 'var(--md-sys-color-on-primary-container)',
                }}
              >
                <CheckCircle2 className="w-12 h-12 stroke-[2.5]" />
              </motion.div>
              <div>
                <h3 className="text-2xl font-black tracking-tight" style={{ color: 'var(--md-sys-color-primary)' }}>
                  Оплата одобрена!
                </h3>
                <p className="text-sm font-semibold mt-1">Приятной поездки! 🚴</p>
                <p className="text-xs opacity-70 mt-1">
                  Велосипед {bike.codeName} разблокирован
                </p>
              </div>
            </div>
          ) : (
            <div className="p-5 space-y-4 overflow-y-auto">
              {/* Cinema Prop Realistic Bank Card Graphic */}
              <div
                className="relative w-full aspect-[1.58/1] rounded-2xl p-5 text-white shadow-xl flex flex-col justify-between overflow-hidden transition-all"
                style={{
                  background:
                    brand === 'tinkoff'
                      ? 'linear-gradient(135deg, #333333 0%, #1e1e1e 100%)'
                      : brand === 'sber'
                      ? 'linear-gradient(135deg, #107c41 0%, #0b5028 100%)'
                      : brand === 'mir'
                      ? 'linear-gradient(135deg, #0f5499 0%, #002b5c 100%)'
                      : 'linear-gradient(135deg, #1e3a8a 0%, #312e81 100%)',
                }}
              >
                {/* Chip & Logo */}
                <div className="flex items-center justify-between">
                  <div className="w-10 h-7 rounded-md bg-amber-300/80 border border-amber-400 flex items-center justify-center">
                    <div className="w-6 h-4 border border-amber-900/40 rounded-sm opacity-60" />
                  </div>
                  <span className="font-bold text-sm tracking-wider uppercase">
                    {brand === 'tinkoff'
                      ? 'T-Bank'
                      : brand === 'sber'
                      ? 'СБЕР'
                      : brand === 'mir'
                      ? 'МИР'
                      : brand === 'visa'
                      ? 'VISA'
                      : brand === 'mastercard'
                      ? 'Mastercard'
                      : 'BANK CARD'}
                  </span>
                </div>

                {/* Card Number */}
                <div className="font-mono text-lg sm:text-xl tracking-widest font-bold my-auto drop-shadow">
                  {cardNumber || '•••• •••• •••• ••••'}
                </div>

                {/* Bottom Row */}
                <div className="flex items-center justify-between text-xs uppercase font-mono tracking-wider">
                  <div>
                    <span className="text-[9px] opacity-75 block">Cardholder</span>
                    <span className="font-bold">{cardholder || 'IVAN IVANOV'}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] opacity-75 block">Expires</span>
                    <span className="font-bold">{expiry || '12/28'}</span>
                  </div>
                </div>
              </div>

              {/* Quick Cinema Presets */}
              <div>
                <span className="text-xs font-semibold opacity-70 block mb-1.5">
                  Быстрый выбор для дубля в фильме:
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    id="preset-tinkoff"
                    type="button"
                    onClick={() => fillPresetCard('tinkoff')}
                    className="flex-1 py-1.5 px-2 rounded-xl text-xs font-semibold border transition-all hover:bg-black/5 dark:hover:bg-white/10"
                    style={{ borderColor: 'var(--md-sys-color-outline)' }}
                  >
                    🟡 Т-Банк
                  </button>
                  <button
                    id="preset-sber"
                    type="button"
                    onClick={() => fillPresetCard('sber')}
                    className="flex-1 py-1.5 px-2 rounded-xl text-xs font-semibold border transition-all hover:bg-black/5 dark:hover:bg-white/10"
                    style={{ borderColor: 'var(--md-sys-color-outline)' }}
                  >
                    🟢 Сбербанк
                  </button>
                  <button
                    id="preset-mir"
                    type="button"
                    onClick={() => fillPresetCard('mir')}
                    className="flex-1 py-1.5 px-2 rounded-xl text-xs font-semibold border transition-all hover:bg-black/5 dark:hover:bg-white/10"
                    style={{ borderColor: 'var(--md-sys-color-outline)' }}
                  >
                    🔵 МИР
                  </button>
                </div>
              </div>

              {/* Input Fields (Accepts ANY text/data) */}
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold opacity-80 block mb-1">
                    Номер карты (любые цифры или текст)
                  </label>
                  <input
                    id="input-card-number"
                    type="text"
                    placeholder="2200 0000 0000 0000"
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    className="w-full py-2.5 px-3.5 rounded-2xl border text-sm font-mono tracking-wider focus:outline-none focus:ring-2"
                    style={{
                      backgroundColor: 'var(--md-sys-color-surface-variant)',
                      color: 'var(--md-sys-color-on-surface-variant)',
                      borderColor: 'transparent',
                    }}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold opacity-80 block mb-1">
                      Срок (ММ/ГГ)
                    </label>
                    <input
                      id="input-card-expiry"
                      type="text"
                      placeholder="12/28"
                      value={expiry}
                      onChange={(e) => setExpiry(e.target.value)}
                      className="w-full py-2.5 px-3.5 rounded-2xl border text-sm font-mono focus:outline-none focus:ring-2"
                      style={{
                        backgroundColor: 'var(--md-sys-color-surface-variant)',
                        color: 'var(--md-sys-color-on-surface-variant)',
                        borderColor: 'transparent',
                      }}
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold opacity-80 block mb-1">
                      CVV / CVC
                    </label>
                    <input
                      id="input-card-cvv"
                      type="password"
                      maxLength={4}
                      placeholder="•••"
                      value={cvv}
                      onChange={(e) => setCvv(e.target.value)}
                      className="w-full py-2.5 px-3.5 rounded-2xl border text-sm font-mono focus:outline-none focus:ring-2"
                      style={{
                        backgroundColor: 'var(--md-sys-color-surface-variant)',
                        color: 'var(--md-sys-color-on-surface-variant)',
                        borderColor: 'transparent',
                      }}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold opacity-80 block mb-1">
                    Имя владельца
                  </label>
                  <input
                    id="input-card-holder"
                    type="text"
                    placeholder="IVAN IVANOV"
                    value={cardholder}
                    onChange={(e) => setCardholder(e.target.value.toUpperCase())}
                    className="w-full py-2.5 px-3.5 rounded-2xl border text-sm uppercase focus:outline-none focus:ring-2"
                    style={{
                      backgroundColor: 'var(--md-sys-color-surface-variant)',
                      color: 'var(--md-sys-color-on-surface-variant)',
                      borderColor: 'transparent',
                    }}
                  />
                </div>
              </div>

              {/* Tariff summary */}
              <div
                className="p-3 rounded-2xl flex items-center justify-between text-xs"
                style={{
                  backgroundColor: 'var(--md-sys-color-secondary-container)',
                  color: 'var(--md-sys-color-on-secondary-container)',
                }}
              >
                <div>
                  <span className="font-bold block">Тариф: {tariff.title}</span>
                  <span className="opacity-80">Стартовый залог / разблокировка:</span>
                </div>
                <span className="font-extrabold text-sm">{tariff.unlockFee} ₽</span>
              </div>

              {/* Pay Button */}
              <button
                id="btn-confirm-payment"
                type="button"
                onClick={handlePay}
                disabled={isProcessing}
                className="w-full py-4 px-6 rounded-3xl font-bold text-base flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] hover:brightness-105 cursor-pointer"
                style={{
                  backgroundColor: 'var(--md-sys-color-primary)',
                  color: 'var(--md-sys-color-on-primary)',
                }}
              >
                {isProcessing ? (
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Авторизация карты...</span>
                  </div>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>Подтвердить и начать поездку</span>
                  </>
                )}
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
