import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Moon,
  Sun,
  Palette,
  Image as ImageIcon,
  Check,
  Sparkles,
  Upload,
  Layers,
  Smartphone,
  Info,
} from 'lucide-react';
import { MaterialColorPalette, ThemeMode } from '../types';
import {
  MATERIAL_YOU_PRESETS,
  extractSeedFromImage,
  generateMaterialPalette,
} from '../utils/theme';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  themeMode: ThemeMode;
  onThemeModeChange: (mode: ThemeMode) => void;
  currentPalette: MaterialColorPalette;
  onPaletteChange: (palette: MaterialColorPalette) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  themeMode,
  onThemeModeChange,
  currentPalette,
  onPaletteChange,
}) => {
  const [customSeed, setCustomSeed] = useState(currentPalette.seedHex);
  const [isExtracting, setIsExtracting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleCustomColor = (hex: string) => {
    setCustomSeed(hex);
    const newPalette = generateMaterialPalette(hex, 'custom-seed', 'Кастомный Material You');
    onPaletteChange(newPalette);
  };

  const handleWallpaperUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsExtracting(true);
      try {
        const seedHex = await extractSeedFromImage(file);
        setCustomSeed(seedHex);
        const dynamicPalette = generateMaterialPalette(
          seedHex,
          'wallpaper-extracted',
          `Обои (${file.name.slice(0, 12)}...)`
        );
        onPaletteChange(dynamicPalette);
      } catch (err) {
        console.error('Failed to extract color from wallpaper:', err);
      } finally {
        setIsExtracting(false);
      }
    }
  };

  return (
    <AnimatePresence>
      <div
        id="settings-modal"
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-md my-auto rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]"
          style={{
            backgroundColor: 'var(--md-sys-color-surface)',
            color: 'var(--md-sys-color-on-surface)',
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-black/5 dark:border-white/10">
            <div className="flex items-center gap-2">
              <Palette className="w-5 h-5" style={{ color: 'var(--md-sys-color-primary)' }} />
              <h2 className="font-bold text-lg">Настройки Material You</h2>
            </div>
            <button
              id="btn-close-settings"
              onClick={onClose}
              className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-5 space-y-6 overflow-y-auto">
            {/* 1. Dark / Light Theme Segmented Switch */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider opacity-70 block">
                Тема оформления (Android 12+)
              </label>
              <div
                className="grid grid-cols-2 p-1 rounded-2xl border"
                style={{
                  backgroundColor: 'var(--md-sys-color-surface-variant)',
                  borderColor: 'transparent',
                }}
              >
                <button
                  id="theme-light-btn"
                  onClick={() => onThemeModeChange('light')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    themeMode === 'light'
                      ? 'shadow-sm'
                      : 'opacity-70 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor:
                      themeMode === 'light'
                        ? 'var(--md-sys-color-surface)'
                        : 'transparent',
                    color: 'var(--md-sys-color-on-surface)',
                  }}
                >
                  <Sun className="w-4 h-4 text-amber-500" />
                  <span>Светлая тема</span>
                </button>

                <button
                  id="theme-dark-btn"
                  onClick={() => onThemeModeChange('dark')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    themeMode === 'dark'
                      ? 'shadow-sm'
                      : 'opacity-70 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor:
                      themeMode === 'dark'
                        ? 'var(--md-sys-color-surface)'
                        : 'transparent',
                    color: 'var(--md-sys-color-on-surface)',
                  }}
                >
                  <Moon className="w-4 h-4 text-indigo-400" />
                  <span>Тёмная тема</span>
                </button>
              </div>
            </div>

            {/* 2. Wallpaper Extraction (Material You Dynamic Palette) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider opacity-70 block">
                  Динамические цвета из обоев
                </label>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                  Android 12+ Monet
                </span>
              </div>

              <div
                className="p-3.5 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-3"
                style={{
                  backgroundColor: 'var(--md-sys-color-surface-variant)',
                  borderColor: 'transparent',
                }}
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0"
                    style={{
                      backgroundColor: 'var(--md-sys-color-primary-container)',
                      color: 'var(--md-sys-color-on-primary-container)',
                    }}
                  >
                    <ImageIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold">Извлечь палитру из обоев</h4>
                    <p className="text-[11px] opacity-75">
                      Загрузите картинку или фон вашего фильма
                    </p>
                  </div>
                </div>

                <button
                  id="btn-upload-wallpaper"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isExtracting}
                  className="w-full sm:w-auto py-2 px-3.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all active:scale-95 cursor-pointer"
                  style={{
                    backgroundColor: 'var(--md-sys-color-primary)',
                    color: 'var(--md-sys-color-on-primary)',
                  }}
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isExtracting ? 'Анализ...' : 'Выбрать фото'}</span>
                </button>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleWallpaperUpload}
                />
              </div>
            </div>

            {/* 3. Preset Material You Palettes */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider opacity-70 block">
                Готовые палитры Material You
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {MATERIAL_YOU_PRESETS.map((preset) => {
                  const isSelected = currentPalette.id === preset.id;
                  return (
                    <button
                      key={preset.id}
                      id={`palette-${preset.id}`}
                      onClick={() => onPaletteChange(preset)}
                      className={`p-2.5 rounded-2xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                        isSelected
                          ? 'ring-2 ring-[var(--md-sys-color-primary)] shadow-sm'
                          : 'opacity-80 hover:opacity-100'
                      }`}
                      style={{
                        backgroundColor: 'var(--md-sys-color-surface-variant)',
                        borderColor: isSelected
                          ? 'var(--md-sys-color-primary)'
                          : 'transparent',
                      }}
                    >
                      <div className="flex items-center gap-2.5">
                        {/* 4-dot preview */}
                        <div className="flex items-center -space-x-1">
                          <span
                            className="w-4 h-4 rounded-full border border-black/20"
                            style={{ backgroundColor: preset.seedHex }}
                          />
                          <span
                            className="w-4 h-4 rounded-full border border-black/20"
                            style={{ backgroundColor: preset.light.primary }}
                          />
                          <span
                            className="w-4 h-4 rounded-full border border-black/20"
                            style={{ backgroundColor: preset.light.secondary }}
                          />
                        </div>
                        <span className="text-xs font-semibold truncate max-w-[110px]">
                          {preset.name}
                        </span>
                      </div>

                      {isSelected && (
                        <Check
                          className="w-4 h-4 stroke-[3]"
                          style={{ color: 'var(--md-sys-color-primary)' }}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Live Palette Swatches Preview */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider opacity-70 block">
                Текущие системные тона (Material 3 Tokens)
              </label>

              <div className="grid grid-cols-4 gap-1.5 text-center text-[10px] font-mono">
                <div
                  className="p-2 rounded-xl"
                  style={{
                    backgroundColor: 'var(--md-sys-color-primary)',
                    color: 'var(--md-sys-color-on-primary)',
                  }}
                >
                  <span className="font-bold block">Primary</span>
                </div>
                <div
                  className="p-2 rounded-xl"
                  style={{
                    backgroundColor: 'var(--md-sys-color-primary-container)',
                    color: 'var(--md-sys-color-on-primary-container)',
                  }}
                >
                  <span className="font-bold block">Container</span>
                </div>
                <div
                  className="p-2 rounded-xl"
                  style={{
                    backgroundColor: 'var(--md-sys-color-secondary)',
                    color: 'var(--md-sys-color-on-secondary)',
                  }}
                >
                  <span className="font-bold block">Secondary</span>
                </div>
                <div
                  className="p-2 rounded-xl border"
                  style={{
                    backgroundColor: 'var(--md-sys-color-surface)',
                    color: 'var(--md-sys-color-on-surface)',
                    borderColor: 'var(--md-sys-color-outline)',
                  }}
                >
                  <span className="font-bold block">Surface</span>
                </div>
              </div>
            </div>

            {/* 5. Custom Seed Hex Picker */}
            <div className="flex items-center justify-between p-3 rounded-2xl bg-black/5 dark:bg-white/5 text-xs">
              <span className="font-medium">Выбрать точный цвет (Hex):</span>
              <div className="flex items-center gap-2">
                <input
                  id="color-picker-seed"
                  type="color"
                  value={customSeed}
                  onChange={(e) => handleCustomColor(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                />
                <span className="font-mono font-bold text-xs uppercase">{customSeed}</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
