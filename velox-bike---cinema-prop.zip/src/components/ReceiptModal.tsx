import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckCircle,
  Receipt,
  Download,
  Share2,
  RotateCcw,
  Bike,
  CreditCard,
  QrCode,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { RideReceipt } from '../types';
import { formatCurrency, formatDistance, formatDuration } from '../utils/gps';

interface ReceiptModalProps {
  receipt: RideReceipt | null;
  onClose: () => void;
  onNewRide: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  receipt,
  onClose,
  onNewRide,
}) => {
  if (!receipt) return null;

  const distanceInfo = formatDistance(receipt.distanceMeters);
  const cardLast4 = receipt.paymentCard.cardNumber.replace(/\s+/g, '').slice(-4) || '7729';

  const handlePrint = () => {
    window.print();
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: `Чек поездки Velox - ${receipt.totalPaid} ₽`,
          text: `Поездка на велосипеде ${receipt.bike.codeName} завершена. Списано: ${receipt.totalPaid} ₽ с карты ****${cardLast4}.`,
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      alert(`Чек #${receipt.receiptId} скопирован для съёмочной группы!`);
    }
  };

  return (
    <AnimatePresence>
      <div
        id="receipt-modal-backdrop"
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 30 }}
          className="relative w-full max-w-md my-auto rounded-3xl overflow-hidden shadow-2xl flex flex-col"
          style={{
            backgroundColor: 'var(--md-sys-color-surface)',
            color: 'var(--md-sys-color-on-surface)',
          }}
        >
          {/* Top Success Banner */}
          <div
            className="p-6 text-center text-white relative overflow-hidden"
            style={{
              backgroundColor: 'var(--md-sys-color-primary)',
            }}
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', damping: 12 }}
              className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center mx-auto mb-3"
            >
              <CheckCircle className="w-10 h-10 text-white" />
            </motion.div>

            <h2 className="text-2xl font-black tracking-tight">Поездка завершена!</h2>
            <p className="text-xs text-white/90 font-medium mt-1">
              Ваши деньги успешно списаны с карты ****{cardLast4}
            </p>
          </div>

          {/* Paper Fiscal Receipt Card */}
          <div className="p-5 space-y-4">
            <div className="p-4 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 font-mono text-xs space-y-2.5">
              {/* Receipt Header */}
              <div className="text-center pb-2 border-b border-dashed border-black/20 dark:border-white/20">
                <span className="font-extrabold text-sm block">ООО «ВЕЛОКС КИНО ШЕРИНГ»</span>
                <span className="text-[10px] opacity-70 block">
                  ФИСКАЛЬНЫЙ ЭЛЕКТРОННЫЙ ЧЕК ККТ
                </span>
                <span className="text-[10px] opacity-70 block">
                  № {receipt.receiptId} • {new Date(receipt.endTime).toLocaleString('ru-RU')}
                </span>
              </div>

              {/* Bike & Tariff Info */}
              <div className="space-y-1 py-1">
                <div className="flex justify-between">
                  <span className="opacity-70">Транспорт:</span>
                  <span className="font-bold">{receipt.bike.codeName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-70">Тариф / Передача:</span>
                  <span className="font-bold">{receipt.tariff.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-70">Дистанция:</span>
                  <span className="font-bold">
                    {distanceInfo.value} {distanceInfo.unit}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-70">Время в пути:</span>
                  <span className="font-bold">
                    {formatDuration(receipt.durationSeconds)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-70">Средняя скорость:</span>
                  <span className="font-bold">{receipt.averageSpeedKmH} км/ч</span>
                </div>
              </div>

              {/* Cost Breakdown */}
              <div className="border-t border-dashed border-black/20 dark:border-white/20 pt-2 space-y-1">
                <div className="flex justify-between">
                  <span className="opacity-70">1. Старт и разблокировка:</span>
                  <span>{receipt.unlockFee.toFixed(1)} ₽</span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-70">2. Пробег ({distanceInfo.value} {distanceInfo.unit}):</span>
                  <span>{receipt.distanceFee.toFixed(1)} ₽</span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-70">3. Время аренды:</span>
                  <span>{receipt.timeFee.toFixed(1)} ₽</span>
                </div>
              </div>

              {/* Total Sum Large */}
              <div className="border-t-2 border-dashed border-black/30 dark:border-white/30 pt-2.5 flex justify-between items-baseline font-sans">
                <span className="text-base font-extrabold uppercase">ИТОГО К ОПЛАТЕ:</span>
                <span
                  className="text-2xl font-black font-mono tracking-tight"
                  style={{ color: 'var(--md-sys-color-primary)' }}
                >
                  {receipt.totalPaid.toFixed(1)} ₽
                </span>
              </div>

              {/* Payment Details */}
              <div className="pt-2 border-t border-dashed border-black/20 dark:border-white/20 flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1.5 opacity-80">
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Карта: **** {cardLast4} ({receipt.paymentCard.cardBrand.toUpperCase()})</span>
                </div>
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">ОПЛАЧЕНО</span>
              </div>

              {/* Simulated QR Code for Fiscal Auth */}
              <div className="pt-2 flex items-center justify-between">
                <div className="space-y-0.5 text-[9px] opacity-60">
                  <p>ФПД: 384910284910</p>
                  <p>ФН: 9960440301928471</p>
                  <p>Сайт ФНС: nalog.gov.ru</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-white p-1 flex items-center justify-center text-black">
                  <QrCode className="w-10 h-10" />
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                id="btn-print-receipt"
                onClick={handlePrint}
                className="py-3 px-3 rounded-2xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors hover:bg-black/5 dark:hover:bg-white/10"
                style={{
                  borderColor: 'var(--md-sys-color-outline)',
                  color: 'var(--md-sys-color-on-surface)',
                }}
              >
                <Download className="w-4 h-4" />
                <span>Сохранить чек</span>
              </button>

              <button
                id="btn-share-receipt"
                onClick={handleShare}
                className="py-3 px-3 rounded-2xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors hover:bg-black/5 dark:hover:bg-white/10"
                style={{
                  borderColor: 'var(--md-sys-color-outline)',
                  color: 'var(--md-sys-color-on-surface)',
                }}
              >
                <Share2 className="w-4 h-4" />
                <span>Поделиться</span>
              </button>
            </div>

            {/* Start New Ride for next movie take */}
            <button
              id="btn-new-ride"
              onClick={onNewRide}
              className="w-full py-4 px-6 rounded-3xl font-extrabold text-base flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] hover:brightness-105 cursor-pointer"
              style={{
                backgroundColor: 'var(--md-sys-color-primary)',
                color: 'var(--md-sys-color-on-primary)',
              }}
            >
              <RotateCcw className="w-5 h-5" />
              <span>Новый дубль / Новая поездка</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
