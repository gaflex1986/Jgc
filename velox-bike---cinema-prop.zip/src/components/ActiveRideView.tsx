import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import {
  Square,
  Bell,
  Navigation,
  Battery,
  Flame,
  Zap,
  Turtle,
  Gauge,
  Sparkles,
  MapPin,
  Pause,
  Play,
  RotateCcw,
  Sliders,
} from 'lucide-react';
import { BikeInfo, PaymentCard, TariffOption, RideState } from '../types';
import { DEFAULT_TARIFFS } from '../data/mockBikes';
import { formatCurrency, formatDistance, formatDuration } from '../utils/gps';
import { playBicycleBell, playBikeLockSound } from '../utils/audio';

interface ActiveRideViewProps {
  bike: BikeInfo;
  tariff: TariffOption;
  paymentCard: PaymentCard;
  onFinishRide: (finalState: {
    durationSeconds: number;
    distanceMeters: number;
    totalCost: number;
    averageSpeedKmH: number;
  }) => void;
}

export const ActiveRideView: React.FC<ActiveRideViewProps> = ({
  bike,
  tariff: initialTariff,
  paymentCard,
  onFinishRide,
}) => {
  const [tariff, setTariff] = useState<TariffOption>(initialTariff);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [distanceMeters, setDistanceMeters] = useState(0);
  const [currentSpeedKmH, setCurrentSpeedKmH] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [useRealGps, setUseRealGps] = useState(false);
  const [simMultiplier, setSimMultiplier] = useState<number>(1);
  const [showDirectorTools, setShowDirectorTools] = useState(false);
  const [showConfirmStop, setShowConfirmStop] = useState(false);
  const [batteryLevel, setBatteryLevel] = useState(bike.batteryLevel);

  const prevLocationRef = useRef<{ lat: number; lng: number } | null>(null);
  const geoWatchIdRef = useRef<number | null>(null);

  // Calculate dynamic total price
  // Formula: Unlock fee + (Distance in meters / 100) * pricePer100m + (time fee: 2 rubles/min)
  const timeMinutes = elapsedSeconds / 60;
  const timeCost = timeMinutes * 2; // subtle minute rate
  const distanceCost = (distanceMeters / 100) * tariff.pricePer100m;
  const totalCost = tariff.unlockFee + distanceCost + timeCost;

  // Sound effect on bell
  const handleRingBell = () => {
    playBicycleBell();
  };

  // Real GPS Geolocation Watcher
  useEffect(() => {
    if (useRealGps && navigator.geolocation) {
      geoWatchIdRef.current = navigator.geolocation.watchPosition(
        (pos) => {
          const { latitude, longitude, speed } = pos.coords;
          if (speed !== null && speed !== undefined) {
            setCurrentSpeedKmH(Math.max(0, Math.round(speed * 3.6)));
          }

          if (prevLocationRef.current) {
            // Distance delta calculation
            const dLat = (latitude - prevLocationRef.current.lat) * 111320;
            const dLng =
              (longitude - prevLocationRef.current.lng) *
              (40075000 * Math.cos((latitude * Math.PI) / 180) / 360);
            const deltaM = Math.sqrt(dLat * dLat + dLng * dLng);
            if (deltaM > 1 && deltaM < 200) {
              setDistanceMeters((prev) => prev + deltaM);
            }
          }
          prevLocationRef.current = { lat: latitude, lng: longitude };
        },
        (err) => {
          console.warn('GPS Error, falling back to simulated motion:', err);
          setUseRealGps(false);
        },
        { enableHighAccuracy: true, maximumAge: 1000 }
      );
    } else {
      if (geoWatchIdRef.current !== null) {
        navigator.geolocation.clearWatch(geoWatchIdRef.current);
        geoWatchIdRef.current = null;
      }
    }

    return () => {
      if (geoWatchIdRef.current !== null) {
        navigator.geolocation.clearWatch(geoWatchIdRef.current);
      }
    };
  }, [useRealGps]);

  // Main Simulation & Ticker Loop
  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      // 1. Increment elapsed time
      setElapsedSeconds((prev) => prev + 1 * simMultiplier);

      // 2. Realistic Simulated Motion & Speed fluctuation
      if (!useRealGps) {
        // Base target speed based on selected Gear
        let targetSpeed = 12;
        if (tariff.gear === 1) targetSpeed = 13.5;
        if (tariff.gear === 2) targetSpeed = 22.8;
        if (tariff.gear === 3) targetSpeed = 39.2;

        // Add organic human cruising fluctuation (±1.5 km/h)
        const organicJitter = (Math.random() - 0.5) * 2.8;
        const currentSpeed = Math.min(
          tariff.maxSpeedKmH,
          Math.max(4, +(targetSpeed + organicJitter).toFixed(1))
        );
        setCurrentSpeedKmH(currentSpeed);

        // Distance in meters per second = (km/h) / 3.6
        const metersPerSec = (currentSpeed / 3.6) * simMultiplier;
        setDistanceMeters((prev) => prev + metersPerSec);
      }

      // 3. Battery slow drain simulation
      if (Math.random() < 0.08 * simMultiplier) {
        setBatteryLevel((prev) => Math.max(5, prev - 1));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isPaused, tariff, simMultiplier, useRealGps]);

  // Finish Ride Handler
  const handleStopRide = () => {
    playBikeLockSound();
    const avgSpeed =
      elapsedSeconds > 0
        ? +((distanceMeters / 1000) / (elapsedSeconds / 3600)).toFixed(1)
        : tariff.maxSpeedKmH * 0.7;

    onFinishRide({
      durationSeconds: Math.max(1, elapsedSeconds),
      distanceMeters: Math.max(10, Math.round(distanceMeters)),
      totalCost: +totalCost.toFixed(2),
      averageSpeedKmH: avgSpeed || 15,
    });
  };

  const distanceInfo = formatDistance(distanceMeters);

  return (
    <div className="w-full max-w-lg mx-auto p-4 space-y-4 select-none pb-20">
      {/* "Приятной поездки!" Prominent Banner */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-3.5 rounded-3xl flex items-center justify-between shadow-sm border"
        style={{
          backgroundColor: 'var(--md-sys-color-primary-container)',
          color: 'var(--md-sys-color-on-primary-container)',
          borderColor: 'transparent',
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-lg shadow-sm"
            style={{
              backgroundColor: 'var(--md-sys-color-primary)',
              color: 'var(--md-sys-color-on-primary)',
            }}
          >
            🔓
          </div>
          <div>
            <h3 className="font-extrabold text-base leading-tight">Приятной поездки!</h3>
            <p className="text-xs opacity-80">
              {bike.codeName} • Передача: {tariff.title.split('.')[1]?.trim() || tariff.title}
            </p>
          </div>
        </div>

        {/* Bike Bell Trigger */}
        <button
          id="btn-bike-bell"
          onClick={handleRingBell}
          className="p-2.5 rounded-2xl border transition-transform active:scale-90 hover:bg-black/5 dark:hover:bg-white/10"
          style={{
            borderColor: 'var(--md-sys-color-outline)',
            backgroundColor: 'var(--md-sys-color-surface)',
            color: 'var(--md-sys-color-on-surface)',
          }}
          title="Позвонить в звонок велосипеда 🔔"
        >
          <Bell className="w-5 h-5 text-amber-500 fill-amber-500/20 animate-wiggle" />
        </button>
      </motion.div>

      {/* Main Speedometer & Dynamic Total Price Gauge */}
      <div
        className="relative p-6 rounded-3xl border shadow-lg overflow-hidden text-center flex flex-col items-center justify-center transition-colors"
        style={{
          backgroundColor: 'var(--md-sys-color-surface)',
          borderColor: 'var(--md-sys-color-outline)',
          color: 'var(--md-sys-color-on-surface)',
        }}
      >
        {/* Dynamic Total Price Display */}
        <div className="w-full flex items-center justify-between px-2 mb-3">
          <div className="text-left">
            <span className="text-[11px] font-semibold uppercase tracking-wider opacity-65 block">
              Итоговая цена
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl sm:text-4xl font-black font-mono tracking-tight" style={{ color: 'var(--md-sys-color-primary)' }}>
                {totalCost.toFixed(1)}
              </span>
              <span className="text-xl font-bold font-mono">₽</span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[11px] font-semibold uppercase tracking-wider opacity-65 block">
              Тариф передачи
            </span>
            <span className="text-xs font-bold font-mono px-2 py-1 rounded-xl bg-black/5 dark:bg-white/10">
              +{tariff.pricePer100m} ₽ / 100м
            </span>
          </div>
        </div>

        {/* Speedometer Center Dial */}
        <div className="relative w-48 h-48 sm:w-56 sm:h-56 flex items-center justify-center my-2">
          {/* Circular Progress Track */}
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="42"
              fill="transparent"
              stroke="currentColor"
              strokeWidth="7"
              className="opacity-10"
            />
            <circle
              cx="50"
              cy="50"
              r="42"
              fill="transparent"
              stroke="var(--md-sys-color-primary)"
              strokeWidth="7"
              strokeDasharray={264}
              strokeDashoffset={264 - (264 * Math.min(currentSpeedKmH, tariff.maxSpeedKmH)) / 50}
              strokeLinecap="round"
              className="transition-all duration-500 ease-out"
            />
          </svg>

          {/* Speed Digital Readout */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-5xl sm:text-6xl font-black font-mono tracking-tighter" style={{ color: 'var(--md-sys-color-primary)' }}>
              {currentSpeedKmH.toFixed(0)}
            </span>
            <span className="text-xs font-bold uppercase tracking-widest opacity-70 mt-[-4px]">
              км / ч
            </span>
            <div className="flex items-center gap-1 mt-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-black/5 dark:bg-white/10">
              <Gauge className="w-3 h-3 text-[var(--md-sys-color-primary)]" />
              <span>Лимит {tariff.maxSpeedKmH} км/ч</span>
            </div>
          </div>
        </div>

        {/* 3 Metric Cards: Distance, Duration, Battery */}
        <div className="w-full grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-black/5 dark:border-white/10">
          <div className="p-2 rounded-2xl bg-black/5 dark:bg-white/5">
            <span className="text-[10px] uppercase font-semibold opacity-60 block">
              Пробег
            </span>
            <span className="text-base sm:text-lg font-mono font-bold">
              {distanceInfo.value}{' '}
              <span className="text-xs font-sans opacity-75">{distanceInfo.unit}</span>
            </span>
          </div>

          <div className="p-2 rounded-2xl bg-black/5 dark:bg-white/5">
            <span className="text-[10px] uppercase font-semibold opacity-60 block">
              Время
            </span>
            <span className="text-base sm:text-lg font-mono font-bold">
              {formatDuration(elapsedSeconds)}
            </span>
          </div>

          <div className="p-2 rounded-2xl bg-black/5 dark:bg-white/5">
            <span className="text-[10px] uppercase font-semibold opacity-60 block">
              Батарея
            </span>
            <span className="text-base sm:text-lg font-mono font-bold text-emerald-600 dark:text-emerald-400">
              {batteryLevel}%
            </span>
          </div>
        </div>
      </div>

      {/* Speed Gear Quick Switcher (1, 2, 3) */}
      <div
        className="p-3 rounded-3xl border flex items-center justify-between gap-1.5"
        style={{
          backgroundColor: 'var(--md-sys-color-surface-variant)',
          color: 'var(--md-sys-color-on-surface-variant)',
          borderColor: 'transparent',
        }}
      >
        <span className="text-xs font-bold pl-2">Передача:</span>
        <div className="flex items-center gap-1 flex-1 justify-end">
          {DEFAULT_TARIFFS.map((t) => {
            const isCurrent = tariff.gear === t.gear;
            return (
              <button
                key={t.gear}
                id={`gear-btn-${t.gear}`}
                onClick={() => setTariff(t)}
                className={`py-1.5 px-3 rounded-2xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                  isCurrent ? 'shadow-md scale-105' : 'opacity-70 hover:opacity-100'
                }`}
                style={{
                  backgroundColor: isCurrent
                    ? 'var(--md-sys-color-primary)'
                    : 'var(--md-sys-color-surface)',
                  color: isCurrent
                    ? 'var(--md-sys-color-on-primary)'
                    : 'var(--md-sys-color-on-surface)',
                }}
              >
                {t.gear === 1 && <Turtle className="w-3.5 h-3.5" />}
                {t.gear === 2 && <Zap className="w-3.5 h-3.5" />}
                {t.gear === 3 && <Flame className="w-3.5 h-3.5" />}
                <span>{t.title.split('.')[1]?.trim() || t.title}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Stop Ride & Pause Controls */}
      <div className="space-y-2 pt-1">
        {showConfirmStop ? (
          <div className="p-4 rounded-3xl bg-red-500/10 border border-red-500/30 text-center space-y-3">
            <h4 className="font-bold text-base text-red-600 dark:text-red-400">
              Завершить поездку и списать {totalCost.toFixed(1)} ₽?
            </h4>
            <div className="flex items-center gap-2">
              <button
                id="btn-cancel-stop"
                onClick={() => setShowConfirmStop(false)}
                className="flex-1 py-3 rounded-2xl font-bold text-xs border transition-colors hover:bg-black/5 dark:hover:bg-white/10"
                style={{ borderColor: 'var(--md-sys-color-outline)' }}
              >
                Продолжить ехать
              </button>
              <button
                id="btn-confirm-stop"
                onClick={handleStopRide}
                className="flex-1 py-3 rounded-2xl font-bold text-xs bg-red-600 hover:bg-red-700 text-white shadow-md transition-all active:scale-95"
              >
                Да, Стоп (Чек)
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            {/* Pause / Resume button */}
            <button
              id="btn-pause-ride"
              onClick={() => setIsPaused((prev) => !prev)}
              className="py-4 px-5 rounded-3xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-colors hover:bg-black/5 dark:hover:bg-white/10"
              style={{
                borderColor: 'var(--md-sys-color-outline)',
                color: 'var(--md-sys-color-on-surface)',
              }}
              title="Пауза поездки"
            >
              {isPaused ? <Play className="w-4 h-4 text-emerald-500" /> : <Pause className="w-4 h-4" />}
              <span>{isPaused ? 'Возобновить' : 'Пауза'}</span>
            </button>

            {/* Stop Ride Big Red Button */}
            <button
              id="btn-stop-ride"
              onClick={() => setShowConfirmStop(true)}
              className="flex-1 py-4 px-6 rounded-3xl font-extrabold text-base bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 cursor-pointer"
            >
              <Square className="w-5 h-5 fill-current" />
              <span>Завершить поездку (СТОП)</span>
            </button>
          </div>
        )}
      </div>

      {/* Cinema Director Tools Accordion */}
      <div className="pt-2">
        <button
          id="btn-toggle-director-tools"
          onClick={() => setShowDirectorTools((prev) => !prev)}
          className="w-full py-2 px-3 rounded-2xl text-xs font-semibold flex items-center justify-between border opacity-80 hover:opacity-100 transition-opacity"
          style={{
            borderColor: 'var(--md-sys-color-outline)',
            backgroundColor: 'var(--md-sys-color-surface-variant)',
            color: 'var(--md-sys-color-on-surface-variant)',
          }}
        >
          <div className="flex items-center gap-2">
            <Sliders className="w-3.5 h-3.5" />
            <span>Панель режиссёра фильма (накрутка / GPS / ускорение)</span>
          </div>
          <span className="text-[10px] font-mono font-bold">
            {showDirectorTools ? 'Скрыть ▲' : 'Развернуть ▼'}
          </span>
        </button>

        {showDirectorTools && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="p-3.5 mt-2 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 space-y-3 text-xs"
          >
            {/* Speed Multiplier for Scene Pacing */}
            <div>
              <span className="font-bold block mb-1.5">
                Ускорение времени для быстрого дубля:
              </span>
              <div className="flex items-center gap-1.5">
                {[1, 2, 5, 10, 20].map((m) => (
                  <button
                    key={m}
                    onClick={() => setSimMultiplier(m)}
                    className={`flex-1 py-1.5 rounded-xl font-mono font-bold transition-all ${
                      simMultiplier === m
                        ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                        : 'bg-black/10 dark:bg-white/10'
                    }`}
                  >
                    {m}x
                  </button>
                ))}
              </div>
            </div>

            {/* Add quick Distance Buttons */}
            <div>
              <span className="font-bold block mb-1.5">
                Быстро накрутить расстояние для сцены:
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setDistanceMeters((d) => d + 500)}
                  className="flex-1 py-1.5 rounded-xl font-mono font-bold bg-black/10 dark:bg-white/10 hover:bg-black/20"
                >
                  +500 м
                </button>
                <button
                  onClick={() => setDistanceMeters((d) => d + 2000)}
                  className="flex-1 py-1.5 rounded-xl font-mono font-bold bg-black/10 dark:bg-white/10 hover:bg-black/20"
                >
                  +2.0 км
                </button>
                <button
                  onClick={() => setDistanceMeters((d) => d + 5000)}
                  className="flex-1 py-1.5 rounded-xl font-mono font-bold bg-black/10 dark:bg-white/10 hover:bg-black/20"
                >
                  +5.0 км
                </button>
              </div>
            </div>

            {/* GPS Toggle */}
            <div className="flex items-center justify-between pt-1">
              <span className="font-semibold">Использовать реальный GPS телефона:</span>
              <button
                onClick={() => setUseRealGps((prev) => !prev)}
                className={`py-1 px-3 rounded-xl font-bold text-xs transition-colors ${
                  useRealGps
                    ? 'bg-emerald-500 text-white'
                    : 'bg-black/10 dark:bg-white/10 text-neutral-600 dark:text-neutral-400'
                }`}
              >
                {useRealGps ? 'Включён 🛰️' : 'Симуляция 🎮'}
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};
