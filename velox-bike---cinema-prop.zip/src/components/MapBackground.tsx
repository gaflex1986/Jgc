import React from 'react';
import { Bike, Navigation, MapPin } from 'lucide-react';
import { SAMPLE_BIKES } from '../data/mockBikes';

interface MapBackgroundProps {
  isRiding?: boolean;
  activeBikeCode?: string;
  onSelectBike?: (bikeId: string) => void;
}

export const MapBackground: React.FC<MapBackgroundProps> = ({
  isRiding,
  activeBikeCode,
  onSelectBike,
}) => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-40 dark:opacity-30">
      {/* Abstract Map Grid Lines */}
      <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern
            id="mapGrid"
            width="80"
            height="80"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 80 0 L 0 0 0 80"
              fill="none"
              stroke="currentColor"
              strokeWidth="0.8"
              className="text-neutral-400 dark:text-neutral-600"
            />
          </pattern>
        </defs>

        <rect width="100%" height="100%" fill="url(#mapGrid)" />

        {/* Diagonal Arterial Roads */}
        <path
          d="M -100 200 Q 300 150 800 500"
          fill="none"
          stroke="currentColor"
          strokeWidth="6"
          className="text-neutral-300 dark:text-neutral-700"
        />
        <path
          d="M 100 0 Q 350 400 200 900"
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
          className="text-neutral-300 dark:text-neutral-700"
        />
        <path
          d="M 0 600 L 900 650"
          fill="none"
          stroke="currentColor"
          strokeWidth="5"
          className="text-neutral-300 dark:text-neutral-700"
        />

        {/* River Arc */}
        <path
          d="M -50 450 C 250 400, 350 700, 750 850"
          fill="none"
          stroke="#38bdf8"
          strokeWidth="16"
          strokeOpacity="0.25"
        />

        {/* Active Route Path if Riding */}
        {isRiding && (
          <path
            d="M 280 410 Q 320 370 380 430 T 450 480"
            fill="none"
            stroke="var(--md-sys-color-primary)"
            strokeWidth="5"
            strokeDasharray="6 4"
            className="animate-pulse"
          />
        )}
      </svg>

      {/* User Location Radar Pulse */}
      <div className="absolute top-[45%] left-[48%] -translate-x-1/2 -translate-y-1/2 flex items-center justify-center">
        <div
          className="w-12 h-12 rounded-full animate-ping opacity-30"
          style={{ backgroundColor: 'var(--md-sys-color-primary)' }}
        />
        <div
          className="absolute w-4 h-4 rounded-full border-2 border-white shadow-md flex items-center justify-center"
          style={{ backgroundColor: 'var(--md-sys-color-primary)' }}
        >
          <div className="w-1.5 h-1.5 rounded-full bg-white" />
        </div>
      </div>

      {/* Nearby Bike Markers on Map */}
      {!isRiding && (
        <>
          <div className="absolute top-[35%] left-[30%] -translate-x-1/2 -translate-y-1/2 p-2 rounded-2xl bg-white dark:bg-neutral-800 shadow-md border border-black/10 flex items-center gap-1.5 text-[10px] font-bold">
            <Bike className="w-3.5 h-3.5 text-emerald-500" />
            <span>#7729 (94%)</span>
          </div>

          <div className="absolute top-[60%] left-[70%] -translate-x-1/2 -translate-y-1/2 p-2 rounded-2xl bg-white dark:bg-neutral-800 shadow-md border border-black/10 flex items-center gap-1.5 text-[10px] font-bold">
            <Bike className="w-3.5 h-3.5 text-blue-500" />
            <span>#8841 (88%)</span>
          </div>

          <div className="absolute top-[28%] left-[75%] -translate-x-1/2 -translate-y-1/2 p-2 rounded-2xl bg-white dark:bg-neutral-800 shadow-md border border-black/10 flex items-center gap-1.5 text-[10px] font-bold">
            <Bike className="w-3.5 h-3.5 text-purple-500" />
            <span>#1024 (99%)</span>
          </div>
        </>
      )}
    </div>
  );
};
