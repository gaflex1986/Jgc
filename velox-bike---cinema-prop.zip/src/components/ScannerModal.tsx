import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Camera,
  Upload,
  Flashlight,
  Sparkles,
  CheckCircle2,
  QrCode,
  Image as ImageIcon,
  AlertCircle,
  Film,
} from 'lucide-react';
import { BikeInfo } from '../types';
import { SAMPLE_BIKES } from '../data/mockBikes';
import { playScannerChirp } from '../utils/audio';

interface ScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBikeScanned: (bike: BikeInfo) => void;
}

export const ScannerModal: React.FC<ScannerModalProps> = ({
  isOpen,
  onClose,
  onBikeScanned,
}) => {
  const [cameraActive, setCameraActive] = useState(false);
  const [torchOn, setTorchOn] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [scannedPreview, setScannedPreview] = useState<string | null>(null);
  const [manualCode, setManualCode] = useState('');
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Initialize camera when modal opens
  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCamera();
      setScannedPreview(null);
      setIsProcessing(false);
    }
    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setCameraActive(true);
      } else {
        setCameraError('Камера недоступна в данном окружении. Используйте загрузку фото или тестовый скан.');
      }
    } catch (err) {
      console.warn('Camera access denied or unavailable:', err);
      setCameraError('Камера не подключена или нет доступа. Можно загрузить фото экранчика велосипеда или нажать "Быстрый скан".');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const toggleTorch = () => {
    if (streamRef.current) {
      const track = streamRef.current.getVideoTracks()[0];
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const imageTrack = track as any;
      if (imageTrack && imageTrack.applyConstraints) {
        imageTrack
          .applyConstraints({
            advanced: [{ torch: !torchOn }],
          })
          .catch(() => {});
      }
    }
    setTorchOn((prev) => !prev);
  };

  const handleRecognize = (customCode?: string, photoUrl?: string) => {
    setIsProcessing(true);
    playScannerChirp();

    setTimeout(() => {
      const selectedBike: BikeInfo = {
        ...SAMPLE_BIKES[0],
        id: customCode || 'BIKE-7729',
        codeName: `⚡ Velox Pro Carbon #${(customCode || '7729').replace(/\D/g, '') || '7729'}`,
        photoUrl: photoUrl || undefined,
      };
      onBikeScanned(selectedBike);
      setIsProcessing(false);
    }, 900);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const url = event.target?.result as string;
        setScannedPreview(url);
        handleRecognize('BIKE-SCREEN-PRO', url);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const url = event.target?.result as string;
        setScannedPreview(url);
        handleRecognize('BIKE-FRAME-PHOTO', url);
      };
      reader.readAsDataURL(file);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div
        id="qr-scanner-modal"
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md"
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-md rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]"
          style={{
            backgroundColor: 'var(--md-sys-color-surface)',
            color: 'var(--md-sys-color-on-surface)',
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-black/5 dark:border-white/10">
            <div className="flex items-center gap-2">
              <QrCode className="w-5 h-5" style={{ color: 'var(--md-sys-color-primary)' }} />
              <h2 className="font-bold text-lg">Сканирование велосипеда</h2>
            </div>
            <button
              id="btn-close-scanner"
              onClick={onClose}
              className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Scanner Viewfinder Box */}
          <div className="relative w-full aspect-square max-h-[320px] bg-neutral-900 overflow-hidden flex items-center justify-center">
            {cameraActive ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            ) : scannedPreview ? (
              <img
                src={scannedPreview}
                alt="Экран велосипеда"
                className="w-full h-full object-contain"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center text-white/70 bg-gradient-to-b from-neutral-800 to-neutral-950">
                <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center mb-3">
                  <Camera className="w-8 h-8 text-white/80 animate-pulse" />
                </div>
                <p className="text-sm font-medium text-white mb-1">
                  Наведите камеру или перетащите фото сюда
                </p>
                <p className="text-xs text-white/60 max-w-[260px]">
                  Подойдёт любой экранчик велосипеда или QR-код для съёмок фильма
                </p>
              </div>
            )}

            {/* Laser reticle animation */}
            <div className="absolute inset-8 pointer-events-none flex items-center justify-center">
              <div className="w-full h-full border-2 border-white/40 rounded-2xl relative">
                {/* Corner markers */}
                <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 rounded-tl-lg" style={{ borderColor: 'var(--md-sys-color-primary)' }} />
                <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 rounded-tr-lg" style={{ borderColor: 'var(--md-sys-color-primary)' }} />
                <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 rounded-bl-lg" style={{ borderColor: 'var(--md-sys-color-primary)' }} />
                <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 rounded-br-lg" style={{ borderColor: 'var(--md-sys-color-primary)' }} />

                {/* Scanning Laser Line */}
                <motion.div
                  className="w-full h-0.5 shadow-[0_0_8px_rgba(255,255,255,0.8)]"
                  style={{ backgroundColor: 'var(--md-sys-color-primary)' }}
                  animate={{ y: [0, 200, 0] }}
                  transition={{ repeat: Infinity, duration: 2.2, ease: 'easeInOut' }}
                />
              </div>
            </div>

            {/* Torch toggle */}
            {cameraActive && (
              <button
                id="btn-scanner-torch"
                onClick={toggleTorch}
                className={`absolute top-4 right-4 p-2.5 rounded-full backdrop-blur-md transition-all ${
                  torchOn ? 'bg-amber-400 text-black shadow-lg shadow-amber-400/50' : 'bg-black/50 text-white'
                }`}
                title="Фонарик"
              >
                <Flashlight className="w-4 h-4" />
              </button>
            )}

            {/* Processing Overlay */}
            {isProcessing && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute inset-0 bg-black/75 backdrop-blur-sm flex flex-col items-center justify-center text-white p-4"
              >
                <CheckCircle2
                  className="w-14 h-14 mb-2 animate-bounce"
                  style={{ color: 'var(--md-sys-color-primary)' }}
                />
                <h4 className="font-bold text-lg">Велосипед распознан!</h4>
                <p className="text-xs text-white/80">Загрузка параметров и тарифов...</p>
              </motion.div>
            )}
          </div>

          {/* Controls & Quick Prop Triggers */}
          <div className="p-4 space-y-3 overflow-y-auto">
            {cameraError && (
              <div className="flex items-start gap-2 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-700 dark:text-amber-300">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{cameraError}</span>
              </div>
            )}

            {/* Fast 1-Tap Cinema Scan Button */}
            <button
              id="btn-quick-cinema-scan"
              onClick={() => handleRecognize('BIKE-7729')}
              disabled={isProcessing}
              className="w-full py-3.5 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98] hover:brightness-105 cursor-pointer"
              style={{
                backgroundColor: 'var(--md-sys-color-primary)',
                color: 'var(--md-sys-color-on-primary)',
              }}
            >
              <Sparkles className="w-4 h-4" />
              <span>Смоделировать скан (Velox Pro #7729)</span>
            </button>

            {/* File Upload Button (For Actor/Director Bike Screen Images) */}
            <div className="grid grid-cols-2 gap-2">
              <button
                id="btn-upload-bike-photo"
                onClick={() => fileInputRef.current?.click()}
                disabled={isProcessing}
                className="py-2.5 px-3 rounded-2xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors hover:bg-black/5 dark:hover:bg-white/10"
                style={{
                  borderColor: 'var(--md-sys-color-outline)',
                  color: 'var(--md-sys-color-on-surface)',
                }}
              >
                <Upload className="w-4 h-4 shrink-0" />
                <span className="truncate">Загрузить фото</span>
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileUpload}
              />

              <button
                id="btn-sample-bike-1024"
                onClick={() => handleRecognize('BIKE-1024')}
                disabled={isProcessing}
                className="py-2.5 px-3 rounded-2xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors hover:bg-black/5 dark:hover:bg-white/10"
                style={{
                  borderColor: 'var(--md-sys-color-outline)',
                  color: 'var(--md-sys-color-on-surface)',
                }}
              >
                <Film className="w-4 h-4 shrink-0" />
                <span className="truncate">Велосипед #1024</span>
              </button>
            </div>

            {/* Manual Code Input */}
            <div className="pt-1">
              <div className="relative flex items-center">
                <input
                  id="input-manual-bike-code"
                  type="text"
                  placeholder="Или введите номер: 7729"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && manualCode) {
                      handleRecognize(manualCode);
                    }
                  }}
                  className="w-full py-2.5 pl-3.5 pr-20 rounded-2xl border text-xs transition-colors focus:outline-none focus:ring-2"
                  style={{
                    backgroundColor: 'var(--md-sys-color-surface-variant)',
                    color: 'var(--md-sys-color-on-surface-variant)',
                    borderColor: 'transparent',
                  }}
                />
                <button
                  id="btn-submit-manual-code"
                  onClick={() => handleRecognize(manualCode || 'BIKE-7729')}
                  className="absolute right-1.5 py-1.5 px-3 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer"
                  style={{
                    backgroundColor: 'var(--md-sys-color-secondary-container)',
                    color: 'var(--md-sys-color-on-secondary-container)',
                  }}
                >
                  Ввести
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
