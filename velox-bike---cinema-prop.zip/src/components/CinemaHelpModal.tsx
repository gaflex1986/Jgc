import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Clapperboard,
  X,
  QrCode,
  CreditCard,
  Gauge,
  Receipt,
  Sparkles,
  Play,
} from 'lucide-react';

interface CinemaHelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onQuickStart: () => void;
}

export const CinemaHelpModal: React.FC<CinemaHelpModalProps> = ({
  isOpen,
  onClose,
  onQuickStart,
}) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div
        id="cinema-help-modal"
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-md my-auto rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]"
          style={{
            backgroundColor: 'var(--md-sys-color-surface)',
            color: 'var(--md-sys-color-on-surface)',
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-black/5 dark:border-white/10">
            <div className="flex items-center gap-2">
              <Clapperboard className="w-5 h-5 text-amber-500" />
              <h2 className="font-bold text-lg">Гид для съёмок фильма</h2>
            </div>
            <button
              id="btn-close-cinema-help"
              onClick={onClose}
              className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-5 space-y-4 text-xs leading-relaxed overflow-y-auto">
            {/* Step 1 */}
            <div className="p-3 rounded-2xl bg-black/5 dark:bg-white/5 space-y-1">
              <div className="flex items-center gap-2 font-bold text-sm">
                <QrCode className="w-4 h-4 text-blue-500" />
                <span>1. Сканирование реквизита</span>
              </div>
              <p className="opacity-80">
                Нажмите <b>«Отсканировать QR-код»</b>. Вы можете навести камеру на реальный QR, загрузить фото любого экранчика велосипеда прямо со съёмочной площадки или нажать <b>«Смоделировать скан»</b> для мгновенного дубля.
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-3 rounded-2xl bg-black/5 dark:bg-white/5 space-y-1">
              <div className="flex items-center gap-2 font-bold text-sm">
                <Gauge className="w-4 h-4 text-emerald-500" />
                <span>2. Выбор передачи и скорости</span>
              </div>
              <p className="opacity-80">
                1-я — <b>Медленно</b> (до 15 км/ч), 2-я — <b>Средняя</b> (до 25 км/ч), 3-я — <b>Экспресс</b> (до 45 км/ч). Цена за километр и скорость спидометра меняются в зависимости от выбранного режима.
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-3 rounded-2xl bg-black/5 dark:bg-white/5 space-y-1">
              <div className="flex items-center gap-2 font-bold text-sm">
                <CreditCard className="w-4 h-4 text-amber-500" />
                <span>3. Поддельная оплата картой</span>
              </div>
              <p className="opacity-80">
                Вводите <b>любые символы, цифры или текст</b> — приложение сочтёт любую карту за настоящую. Есть кнопки быстрого выбора (Т-Банк, Сбер, МИР) для актеров в кадре.
              </p>
            </div>

            {/* Step 4 */}
            <div className="p-3 rounded-2xl bg-black/5 dark:bg-white/5 space-y-1">
              <div className="flex items-center gap-2 font-bold text-sm">
                <Receipt className="w-4 h-4 text-purple-500" />
                <span>4. Пробег, цена в реальном времени и Чек</span>
              </div>
              <p className="opacity-80">
                Во время движения спидометр реалистично колеблется, километраж накручивается, а итоговая цена растёт с каждым метром. По кнопке <b>«СТОП»</b> появляется уведомление «Ваши деньги списались» и подробный фискальный чек.
              </p>
            </div>

            {/* Step 5 */}
            <div className="p-3 rounded-2xl bg-black/5 dark:bg-white/5 space-y-1">
              <div className="flex items-center gap-2 font-bold text-sm">
                <Sparkles className="w-4 h-4 text-pink-500" />
                <span>5. Material You & Палитра под обои</span>
              </div>
              <p className="opacity-80">
                В настройках можно загрузить кадр обоев фильма — интерфейс перекрасится в точности под Android 12+ Monet тона!
              </p>
            </div>

            <button
              id="btn-cinema-start"
              onClick={() => {
                onClose();
                onQuickStart();
              }}
              className="w-full py-3.5 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
              style={{
                backgroundColor: 'var(--md-sys-color-primary)',
                color: 'var(--md-sys-color-on-primary)',
              }}
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Понятно, начать съёмку дубля!</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
