import React from 'react';
import { motion } from 'motion/react';
import {
  Bike,
  Battery,
  Gauge,
  Zap,
  Flame,
  Turtle,
  Check,
  ChevronRight,
  ShieldCheck,
  MapPin,
} from 'lucide-react';
import { BikeInfo, TariffOption } from '../types';
import { DEFAULT_TARIFFS } from '../data/mockBikes';

interface TariffSelectorProps {
  bike: BikeInfo;
  selectedTariff: TariffOption;
  onSelectTariff: (tariff: TariffOption) => void;
  onProceedToRent: () => void;
  onRescan: () => void;
}

export const TariffSelector: React.FC<TariffSelectorProps> = ({
  bike,
  selectedTariff,
  onSelectTariff,
  onProceedToRent,
  onRescan,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      className="w-full max-w-lg mx-auto p-4 space-y-4"
    >
      {/* Bike Recognized Banner */}
      <div
        className="p-4 rounded-3xl border shadow-sm flex items-center justify-between transition-colors"
        style={{
          backgroundColor: 'var(--md-sys-color-surface-variant)',
          borderColor: 'transparent',
          color: 'var(--md-sys-color-on-surface-variant)',
        }}
      >
        <div className="flex items-center gap-3.5">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-inner"
            style={{
              backgroundColor: 'var(--md-sys-color-primary-container)',
              color: 'var(--md-sys-color-on-primary-container)',
            }}
          >
            <Bike className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-base text-[var(--md-sys-color-on-surface)]">
                {bike.codeName}
              </span>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                Готов к поездке
              </span>
            </div>
            <div className="flex items-center gap-3 text-xs mt-0.5 opacity-80">
              <span className="flex items-center gap-1">
                <Battery className="w-3.5 h-3.5 text-emerald-500" /> {bike.batteryLevel}% (~{bike.estimatedRangeKm} км)
              </span>
              <span className="flex items-center gap-1 truncate max-w-[150px]">
                <MapPin className="w-3 h-3" /> {bike.locationName}
              </span>
            </div>
          </div>
        </div>

        <button
          id="btn-change-bike"
          onClick={onRescan}
          className="text-xs font-semibold px-2.5 py-1.5 rounded-xl transition-colors hover:bg-black/5 dark:hover:bg-white/10"
          style={{ color: 'var(--md-sys-color-primary)' }}
        >
          Другой
        </button>
      </div>

      {/* Speed & Tariff Options Title */}
      <div>
        <h2 className="text-xl font-extrabold tracking-tight px-1" style={{ color: 'var(--md-sys-color-on-surface)' }}>
          Выберите скорость и тариф
        </h2>
        <p className="text-xs px-1 mt-0.5 opacity-70" style={{ color: 'var(--md-sys-color-on-surface)' }}>
          Передача скорости определяет максимальную скорость и тариф за 1 км
        </p>
      </div>

      {/* 3 Speed Gears Cards */}
      <div className="space-y-3">
        {DEFAULT_TARIFFS.map((tariff) => {
          const isSelected = selectedTariff.gear === tariff.gear;

          return (
            <motion.div
              key={tariff.gear}
              whileTap={{ scale: 0.98 }}
              onClick={() => onSelectTariff(tariff)}
              id={`tariff-card-${tariff.gear}`}
              className={`relative p-4 rounded-3xl border-2 transition-all cursor-pointer select-none ${
                isSelected
                  ? 'shadow-md ring-2 ring-[var(--md-sys-color-primary)]/20'
                  : 'hover:border-neutral-400/40 dark:hover:border-neutral-600/50 opacity-90'
              }`}
              style={{
                backgroundColor: isSelected
                  ? 'var(--md-sys-color-primary-container)'
                  : 'var(--md-sys-color-surface)',
                borderColor: isSelected
                  ? 'var(--md-sys-color-primary)'
                  : 'var(--md-sys-color-outline)',
                color: isSelected
                  ? 'var(--md-sys-color-on-primary-container)'
                  : 'var(--md-sys-color-on-surface)',
              }}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  {/* Gear Icon */}
                  <div
                    className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 mt-0.5"
                    style={{
                      backgroundColor: isSelected
                        ? 'var(--md-sys-color-primary)'
                        : 'var(--md-sys-color-surface-variant)',
                      color: isSelected
                        ? 'var(--md-sys-color-on-primary)'
                        : 'var(--md-sys-color-on-surface-variant)',
                    }}
                  >
                    {tariff.gear === 1 && <Turtle className="w-5 h-5" />}
                    {tariff.gear === 2 && <Zap className="w-5 h-5" />}
                    {tariff.gear === 3 && <Flame className="w-5 h-5" />}
                  </div>

                  {/* Info */}
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-base">{tariff.title}</h3>
                      <span
                        className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full"
                        style={{
                          backgroundColor: isSelected
                            ? 'var(--md-sys-color-surface)'
                            : 'var(--md-sys-color-secondary-container)',
                          color: isSelected
                            ? 'var(--md-sys-color-on-surface)'
                            : 'var(--md-sys-color-on-secondary-container)',
                        }}
                      >
                        до {tariff.maxSpeedKmH} км/ч
                      </span>
                    </div>

                    <p className="text-xs opacity-75 mt-0.5">{tariff.subtitle}</p>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-2 text-xs font-semibold">
                      <span className="text-[var(--md-sys-color-primary)] font-bold">
                        {tariff.pricePer100m} ₽ / 100 м
                      </span>
                      <span className="opacity-60">•</span>
                      <span className="opacity-80">
                        {tariff.pricePerKm} ₽ / км
                      </span>
                      <span className="opacity-60">•</span>
                      <span className="opacity-80">
                        Старт: {tariff.unlockFee} ₽
                      </span>
                    </div>
                  </div>
                </div>

                {/* Selection Radio Circle */}
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center transition-all shrink-0 ${
                    isSelected ? 'scale-110 shadow-sm' : 'border-2 border-neutral-400'
                  }`}
                  style={{
                    backgroundColor: isSelected ? 'var(--md-sys-color-primary)' : 'transparent',
                    color: 'var(--md-sys-color-on-primary)',
                  }}
                >
                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Safety & Cinema Prop Badge */}
      <div className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-black/5 dark:bg-white/5 text-xs opacity-75">
        <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
        <span>Кино-режим: оплата и пробег работают понарошку без реальных списаний.</span>
      </div>

      {/* Bottom Action Button */}
      <div className="pt-2">
        <button
          id="btn-proceed-to-rent"
          onClick={onProceedToRent}
          className="w-full py-4 px-6 rounded-3xl font-bold text-base flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] hover:brightness-105 cursor-pointer"
          style={{
            backgroundColor: 'var(--md-sys-color-primary)',
            color: 'var(--md-sys-color-on-primary)',
          }}
        >
          <span>Арендовать ({selectedTariff.title.split('.')[1]?.trim() || selectedTariff.title})</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </motion.div>
  );
};
