import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Copy, Check, Code, Smartphone, Sparkles, Layers, ShieldCheck } from 'lucide-react';
import {
  JETPACK_COMPOSE_THEME_KT,
  JETPACK_COMPOSE_COLOR_KT,
  JETPACK_COMPOSE_MAIN_ACTIVITY_KT,
} from '../data/composeKotlinSource';

interface ComposeCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const REQUIREMENTS = [
  {
    id: 1,
    title: 'Material Design 3 (M3)',
    desc: 'Используется исключительно androidx.compose.material3.* (MaterialTheme, Scaffold, CenterAlignedTopAppBar, Card, FilledButton, FloatingActionButton). Компоненты Material 2 полностью исключены.',
    badge: 'M3 Strict',
  },
  {
    id: 2,
    title: 'Dynamic Colors (Android 12+ / API 31+)',
    desc: 'Проверка Build.VERSION.SDK_INT >= Build.VERSION_CODES.S с вызовом dynamicLightColorScheme(context) и dynamicDarkColorScheme(context), а также fallback на статичные схемы.',
    badge: 'Monet Engine',
  },
  {
    id: 3,
    title: 'Кастомная тема AppTheme',
    desc: 'Сигнатура AppTheme(darkTheme: Boolean = isSystemInDarkTheme(), dynamicColor: Boolean = true, content: @Composable () -> Unit) с автоматической настройкой StatusBar.',
    badge: 'AppTheme',
  },
  {
    id: 4,
    title: 'Авто-переключение Dark / Light Mode',
    desc: 'Поддержка системной темы isSystemInDarkTheme() и ручного переключателя темы в рантайме.',
    badge: 'System Dark Mode',
  },
  {
    id: 5,
    title: 'M3-компоненты',
    desc: 'Scaffold с innerPadding, CenterAlignedTopAppBar с токенами surfaceContainer, карточки с RoundedCornerShape(28.dp), NavigationBar.',
    badge: 'Components',
  },
  {
    id: 6,
    title: 'Семантические цвета MaterialTheme.colorScheme',
    desc: 'Все цвета ссылаются на токены схемы: primary, onPrimary, surface, onSurface, surfaceContainer, outlineVariant без хардкода.',
    badge: 'Semantic Tokens',
  },
];

export const ComposeCodeModal: React.FC<ComposeCodeModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'theme' | 'color' | 'main' | 'checklist'>('theme');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const getActiveCode = () => {
    switch (activeTab) {
      case 'theme':
        return { filename: 'ui/theme/Theme.kt', code: JETPACK_COMPOSE_THEME_KT };
      case 'color':
        return { filename: 'ui/theme/Color.kt', code: JETPACK_COMPOSE_COLOR_KT };
      case 'main':
        return { filename: 'MainActivity.kt', code: JETPACK_COMPOSE_MAIN_ACTIVITY_KT };
      default:
        return { filename: 'Checklist', code: '' };
    }
  };

  const current = getActiveCode();

  const handleCopy = () => {
    if (current.code) {
      navigator.clipboard.writeText(current.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="w-full max-w-3xl max-h-[90vh] flex flex-col rounded-3xl overflow-hidden shadow-2xl border"
          style={{
            backgroundColor: 'var(--md-sys-color-surface)',
            color: 'var(--md-sys-color-on-surface)',
            borderColor: 'var(--md-sys-color-outline)',
          }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-6 py-4 border-b"
            style={{
              backgroundColor: 'var(--md-sys-color-surface-variant)',
              borderColor: 'var(--md-sys-color-outline)',
            }}
          >
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-2xl flex items-center justify-center"
                style={{
                  backgroundColor: 'var(--md-sys-color-primary-container)',
                  color: 'var(--md-sys-color-on-primary-container)',
                }}
              >
                <Code className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-base">Jetpack Compose (Material 3)</h3>
                  <span
                    className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                    style={{
                      backgroundColor: 'var(--md-sys-color-primary)',
                      color: 'var(--md-sys-color-on-primary)',
                    }}
                  >
                    Android 12+ Ready
                  </span>
                </div>
                <p className="text-xs opacity-75">
                  Полная реализация Dynamic Color (Material You) и архитектуры M3
                </p>
              </div>
            </div>

            <button
              id="btn-close-compose-modal"
              onClick={onClose}
              className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div
            className="flex items-center gap-2 px-6 py-2 border-b overflow-x-auto"
            style={{
              backgroundColor: 'var(--md-sys-color-surface)',
              borderColor: 'var(--md-sys-color-outline)',
            }}
          >
            <button
              id="tab-theme-kt"
              onClick={() => setActiveTab('theme')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'theme' ? 'shadow-sm' : 'opacity-70 hover:opacity-100'
              }`}
              style={{
                backgroundColor:
                  activeTab === 'theme'
                    ? 'var(--md-sys-color-primary-container)'
                    : 'transparent',
                color:
                  activeTab === 'theme'
                    ? 'var(--md-sys-color-on-primary-container)'
                    : 'inherit',
              }}
            >
              <Sparkles className="w-3.5 h-3.5" />
              Theme.kt (AppTheme)
            </button>

            <button
              id="tab-color-kt"
              onClick={() => setActiveTab('color')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'color' ? 'shadow-sm' : 'opacity-70 hover:opacity-100'
              }`}
              style={{
                backgroundColor:
                  activeTab === 'color'
                    ? 'var(--md-sys-color-primary-container)'
                    : 'transparent',
                color:
                  activeTab === 'color'
                    ? 'var(--md-sys-color-on-primary-container)'
                    : 'inherit',
              }}
            >
              <Layers className="w-3.5 h-3.5" />
              Color.kt (M3 Tokens)
            </button>

            <button
              id="tab-main-kt"
              onClick={() => setActiveTab('main')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'main' ? 'shadow-sm' : 'opacity-70 hover:opacity-100'
              }`}
              style={{
                backgroundColor:
                  activeTab === 'main'
                    ? 'var(--md-sys-color-primary-container)'
                    : 'transparent',
                color:
                  activeTab === 'main'
                    ? 'var(--md-sys-color-on-primary-container)'
                    : 'inherit',
              }}
            >
              <Smartphone className="w-3.5 h-3.5" />
              MainActivity.kt
            </button>

            <button
              id="tab-checklist"
              onClick={() => setActiveTab('checklist')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'checklist' ? 'shadow-sm' : 'opacity-70 hover:opacity-100'
              }`}
              style={{
                backgroundColor:
                  activeTab === 'checklist'
                    ? 'var(--md-sys-color-primary-container)'
                    : 'transparent',
                color:
                  activeTab === 'checklist'
                    ? 'var(--md-sys-color-on-primary-container)'
                    : 'inherit',
              }}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Чеклист 6 требований
            </button>
          </div>

          {/* Body / Content */}
          <div className="flex-1 p-5 overflow-y-auto bg-black/5 dark:bg-black/40 font-mono text-xs">
            {activeTab === 'checklist' ? (
              <div className="space-y-3 font-sans">
                {REQUIREMENTS.map((req) => (
                  <div
                    key={req.id}
                    className="p-4 rounded-2xl border flex items-start gap-3.5"
                    style={{
                      backgroundColor: 'var(--md-sys-color-surface)',
                      borderColor: 'var(--md-sys-color-outline)',
                    }}
                  >
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-bold"
                      style={{
                        backgroundColor: 'var(--md-sys-color-primary)',
                        color: 'var(--md-sys-color-on-primary)',
                      }}
                    >
                      {req.id}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-bold text-sm">{req.title}</h4>
                        <span
                          className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                          style={{
                            backgroundColor: 'var(--md-sys-color-secondary-container)',
                            color: 'var(--md-sys-color-on-secondary-container)',
                          }}
                        >
                          {req.badge}
                        </span>
                      </div>
                      <p className="text-xs opacity-80 leading-relaxed">{req.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="relative">
                <div className="flex items-center justify-between mb-2 font-mono text-[11px] opacity-70">
                  <span>📄 {current.filename}</span>
                  <span>Kotlin • Material 3</span>
                </div>
                <pre
                  className="p-4 rounded-2xl overflow-x-auto text-[11px] leading-relaxed select-text border"
                  style={{
                    backgroundColor: 'var(--md-sys-color-surface)',
                    color: 'var(--md-sys-color-on-surface)',
                    borderColor: 'var(--md-sys-color-outline)',
                  }}
                >
                  <code>{current.code}</code>
                </pre>
              </div>
            )}
          </div>

          {/* Footer */}
          <div
            className="flex items-center justify-between px-6 py-3 border-t"
            style={{
              backgroundColor: 'var(--md-sys-color-surface-variant)',
              borderColor: 'var(--md-sys-color-outline)',
            }}
          >
            <div className="text-xs opacity-75">
              Скопируйте файлы в <code className="font-mono font-bold">src/main/java/...</code> вашего проекта Android Studio
            </div>

            {activeTab !== 'checklist' && (
              <button
                id="btn-copy-compose-code"
                onClick={handleCopy}
                className="px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-transform active:scale-95 shadow-sm"
                style={{
                  backgroundColor: 'var(--md-sys-color-primary)',
                  color: 'var(--md-sys-color-on-primary)',
                }}
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copied ? 'Скопировано!' : 'Скопировать код'}
              </button>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
