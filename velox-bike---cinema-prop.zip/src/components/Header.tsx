import React, { useEffect, useState } from 'react';
import { Settings, Battery, Wifi, Sparkles, Clapperboard, Code2 } from 'lucide-react';
import { BikeInfo, ThemeMode } from '../types';

interface HeaderProps {
  themeMode: ThemeMode;
  isDark: boolean;
  onOpenSettings: () => void;
  onOpenCinemaHelp: () => void;
  onOpenComposeCode?: () => void;
  activeBike?: BikeInfo | null;
  isRiding?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSettings,
  onOpenCinemaHelp,
  onOpenComposeCode,
  activeBike,
  isRiding,
}) => {
  const [time, setTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString('ru-RU', {
          hour: '2-digit',
          minute: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="w-full select-none z-30">
      {/* Android 12+ Material You Status Bar */}
      <div className="flex items-center justify-between px-6 pt-2 pb-1 text-xs font-medium opacity-80" style={{ color: 'var(--md-sys-color-on-surface)' }}>
        <span className="tracking-wide font-semibold text-[13px]">{time || '12:00'}</span>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono font-semibold px-1 rounded bg-black/10 dark:bg-white/10">5G</span>
          <Wifi className="w-3.5 h-3.5" />
          <div className="flex items-center gap-1">
            <span className="text-[11px] font-mono">92%</span>
            <Battery className="w-3.5 h-3.5 fill-current" />
          </div>
        </div>
      </div>

      {/* Main Material 3 App Bar */}
      <div
        className="flex items-center justify-between px-5 py-3 transition-colors"
        style={{
          backgroundColor: 'transparent',
          color: 'var(--md-sys-color-on-surface)',
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center shadow-sm"
            style={{
              backgroundColor: 'var(--md-sys-color-primary)',
              color: 'var(--md-sys-color-on-primary)',
            }}
          >
            <span className="font-black tracking-wider text-lg">V</span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-lg leading-tight tracking-tight">Velox Ride</h1>
              <span
                className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full"
                style={{
                  backgroundColor: 'var(--md-sys-color-secondary-container)',
                  color: 'var(--md-sys-color-on-secondary-container)',
                }}
              >
                Кино-реквизит
              </span>
            </div>
            <p className="text-xs opacity-70">
              {isRiding && activeBike
                ? `В поездке: ${activeBike.codeName}`
                : 'Городской прокат электровелосипедов'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {onOpenComposeCode && (
            <button
              id="btn-open-compose-code"
              onClick={onOpenComposeCode}
              aria-label="Jetpack Compose M3 Code"
              className="px-2.5 py-1.5 rounded-xl flex items-center gap-1 text-xs font-semibold transition-transform active:scale-95 border"
              style={{
                backgroundColor: 'var(--md-sys-color-primary-container)',
                color: 'var(--md-sys-color-on-primary-container)',
                borderColor: 'var(--md-sys-color-outline)',
              }}
              title="Требования и код Jetpack Compose M3"
            >
              <Code2 className="w-4 h-4" />
              <span className="hidden sm:inline">Compose M3</span>
            </button>
          )}

          <button
            id="btn-cinema-help"
            onClick={onOpenCinemaHelp}
            aria-label="Подсказки для съёмки"
            className="w-9 h-9 rounded-full flex items-center justify-center transition-transform active:scale-95 hover:bg-black/5 dark:hover:bg-white/10"
            style={{ color: 'var(--md-sys-color-on-surface)' }}
            title="Инструкция для режиссёра / оператора"
          >
            <Clapperboard className="w-5 h-5" />
          </button>

          <button
            id="btn-open-settings"
            onClick={onOpenSettings}
            aria-label="Настройки и темы Material You"
            className="w-9 h-9 rounded-full flex items-center justify-center transition-transform active:scale-95 hover:bg-black/5 dark:hover:bg-white/10"
            style={{ color: 'var(--md-sys-color-on-surface)' }}
            title="Настройки Material You"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
