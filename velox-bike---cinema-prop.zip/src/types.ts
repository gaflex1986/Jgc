export type ThemeMode = 'dark' | 'light' | 'system';

export interface MaterialColorPalette {
  id: string;
  name: string;
  seedHex: string;
  // Dynamic tones for Light and Dark
  light: {
    primary: string;
    onPrimary: string;
    primaryContainer: string;
    onPrimaryContainer: string;
    secondary: string;
    onSecondary: string;
    secondaryContainer: string;
    surface: string;
    surfaceVariant: string;
    onSurface: string;
    onSurfaceVariant: string;
    background: string;
    onBackground: string;
    outline: string;
    error: string;
  };
  dark: {
    primary: string;
    onPrimary: string;
    primaryContainer: string;
    onPrimaryContainer: string;
    secondary: string;
    onSecondary: string;
    secondaryContainer: string;
    surface: string;
    surfaceVariant: string;
    onSurface: string;
    onSurfaceVariant: string;
    background: string;
    onBackground: string;
    outline: string;
    error: string;
  };
}

export type SpeedGear = 1 | 2 | 3;

export interface TariffOption {
  gear: SpeedGear;
  title: string;
  subtitle: string;
  maxSpeedKmH: number;
  pricePer100m: number; // in rubles (or current currency)
  pricePerKm: number;
  unlockFee: number;
  batteryEcoRating: string;
  iconName: 'Turtle' | 'Zap' | 'Flame';
  colorTag: string;
  description: string;
}

export interface BikeInfo {
  id: string;
  codeName: string;
  model: string;
  batteryLevel: number;
  estimatedRangeKm: number;
  locationName: string;
  isLocked: boolean;
  photoUrl?: string;
}

export interface PaymentCard {
  cardNumber: string;
  expiry: string;
  cvv: string;
  cardholder: string;
  cardBrand: 'mir' | 'visa' | 'mastercard' | 'tinkoff' | 'sber' | 'generic';
}

export interface RideState {
  isActive: boolean;
  isPaused: boolean;
  startTime: number;
  endTime?: number;
  elapsedSeconds: number;
  distanceMeters: number;
  currentSpeedKmH: number;
  totalCost: number;
  tariff: TariffOption;
  bike: BikeInfo;
  paymentCard: PaymentCard;
  simulationMultiplier: number; // 1x, 2x, 5x for movie scene speed up
  useRealGps: boolean;
  routeCoordinates: Array<{ lat: number; lng: number; timestamp: number }>;
}

export interface RideReceipt {
  receiptId: string;
  timestamp: number;
  bike: BikeInfo;
  tariff: TariffOption;
  paymentCard: PaymentCard;
  startTime: number;
  endTime: number;
  durationSeconds: number;
  distanceMeters: number;
  averageSpeedKmH: number;
  unlockFee: number;
  distanceFee: number;
  timeFee: number;
  totalPaid: number;
  transactionRef: string;
}
